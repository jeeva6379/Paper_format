const UserData = require("../models/UserSchema");
const jwt = require("jsonwebtoken");


const TokenAuthentication = (req, res, next) => {
  // Verify the token in the Authorization header
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  // Verify the token
  jwt.verify(token, process.env.JWT_SECRET_KEY, { expiresIn: "1h" }, async (err, decoded) => {
    if (err) {
      // console.log("err", err);
      return res.status(401).json({ message: "Invalid token" });
    }
    let decodedEmail = decoded.email;

    const user = await UserData.findOne({ email: decodedEmail }).select("-password");

    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    req.user = user;
    next();
  });
};

module.exports = TokenAuthentication;
