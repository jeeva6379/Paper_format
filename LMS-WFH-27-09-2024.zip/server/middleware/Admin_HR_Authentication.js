const Admin_HR_Authentication = (req, res, next) => {
  const user = req.user;
  if (!user) return res.status(404).json({ message: "User not found" });

  if (user.role === "Admin" || user.role === "HR") {
    return next();
  }

  res.status(401).json({ message: "Unauthorized" });
};

module.exports = Admin_HR_Authentication;
