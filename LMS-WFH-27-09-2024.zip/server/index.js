const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const mongoose = require("mongoose");
const moment = require("moment");
require("dotenv").config();
const jwt = require("jsonwebtoken");
const fs = require("fs");
const { isValidObjectId } = require('mongoose'); 
const bodyParser = require('body-parser');
const nodemailer = require("nodemailer");
const TokenAuthentication  = require('./middleware/TokenAuthentication');
const Admin_HR_Authentication  = require('./middleware/Admin_HR_Authentication');
const UserData = require("./models/UserSchema");
const LeaveApplication = require('./models/LeaveApplicationSchema');  
const { log } = require("console");

const sendEmail = async (email, subject, text) => {
 try {
 const transporter = nodemailer.createTransport({
 host: process.env.HOST,
 service: process.env.SERVICE,
port: 587,
secure: true,
auth: {
user: process.env.USER,
pass: process.env.PASS,
}, });

await transporter.sendMail({
 from: process.env.USER,
 to: email,
subject: subject,
text: text });

console.log("email sent sucessfully");
} catch (error) {
 console.log(error, "email not sent"); } };

 module.exports = sendEmail;
const { Schema } = mongoose;



const app = express();
app.use(bodyParser.json()); 

app.use("/profile_picture", express.static(path.join(__dirname, "profile_picture")));

app.use("/medical_certificate",express.static(path.join(__dirname, "medical_certificate")));

const port = process.env.PORT || 2222;

const storage = multer.diskStorage({
  destination: "profile_picture/",
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const originalFileName = file.originalname;
    // const uniqueIdentifier = Date.now();
    // const newFileName = `${originalFileName}-${uniqueIdentifier}${ext}`;
    
    cb(null, originalFileName);
  },
});
const upload = multer({ storage: storage });


app.use(cors());
app.use(express.json());



mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB successfully");
  })
  .catch((error) => {
    console.error("Error connecting to MongoDB:", error);
  });

//user data get front-end api routes start

app.post("/api/userdata", TokenAuthentication, Admin_HR_Authentication,  upload.single("Uploadimage"), async (req, res) => {
  try {
    const {
      name,
      company,
      email,
      password,
      role,
      emp_id,
      designation,
      date_of_joining,
    } = req.body;

    const uploadImage = req.file;
    const originalFileName = uploadImage.originalname;

    const formattedCreatedAt = moment(UserData.createdAt).format(
      "YYYY-MM-DD HH:mm:ss"
    );

    const userData = new UserData({
      name,
      company,
      email,
      password,
      role,
      emp_id,
      designation,
      date_of_joining,
      originalFileName,
      createdAt: formattedCreatedAt,
    });

    await userData.save();

    // console.log("Received user data", req.body);
    // console.log("Received image file", uploadImage);
    res.json({ message: "User created successfully" });
  } catch (error) {
    console.error("Error handling request", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

//user data get front-end api routes end

// *****************************************************

// fetch  all user data to get the route start

// Route to fetch user data
app.get("/api/userdata",  TokenAuthentication, Admin_HR_Authentication, async (req, res) => {
  try {
    const users = await UserData.find();
    // console.log("Fetched users:", users);
    res.json(users);
    
  } catch (error) {
    console.error("Error fetching users", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

app.get("/api/alternation-users-list/:id",  TokenAuthentication, async (req, res) => {
  const {id} = req.params

  try {
    const users = await UserData.find({_id: {$ne: id}, role: {$ne: "Admin"}}).select('_id, name');
    // console.log("Fetched users:", users);
    if(!users) return res.status(404).json({ message: "no users" }); 
    res.json(users);
    
  } catch (error) {
    console.error("Error fetching users", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
})





// fetch  all user data to get the route end

// *****************************************************

// fetch the data from to set login and password fields start

const secretKey = process.env.JWT_SECRET_KEY;

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  // console.log("login data", req.body);

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  try {
    // Find user by email
    const user = await UserData.findOne({ email });
    // console.log("user found", user);

    if (!user) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // Check if password is correct
    // const isPasswordValid = await bcrypt.compare(password, user.password);

    if (password !== user.password) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    // If email and password are correct, generate JWT token
    const token = jwt.sign({ email: user.email, userId: user._id }, secretKey, {
      expiresIn: "1h",
    });
    


  

    res.status(200).json({message: "Successfully Logged In", token});
  } catch (error) {
    console.error("Error logging in:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Login Endpoint



// fetch the data from to set login and password fields end

// app.get("/api/current-user",  TokenAuthentication, (req, res) => {
//   const user = req.user
//   try {
//       // let profile_pic_url = `http://192.168.0.103:2222/profile_picture/${user.originalFileName}`;
//       let profile_pic_url = `${process.env.API_URL}/profile_picture/${user.originalFileName}`;

//       fs.access(profile_pic_url, fs.constants.F_OK, (err) => {
//         if (err) {
//           // profile_pic_url = `http://192.168.0.103:2222/profile_picture/user.png`;
//           profile_pic_url = `${process.env.API_URL}/profile_picture/user.png`;
//           return;
//         }
//       });
//     // Fetch casual leave status for the current month
//     const currentDate = new Date();
//     const currentMonth = currentDate.getMonth() + 1; // JavaScript months are 0-based
//     const currentYear = currentDate.getFullYear();

//     const leaveYear = user.leaveDetails.find(ld => ld.year === currentYear);
//     const clTaken = leaveYear && leaveYear.months.find(m => m.month === currentMonth)?.clTaken || false;

//     // Respond with user details, token, and casual leave status
//     return res.json({
//       userId: user._id,
//       name: user.name,
//       email: user.email,
//       clTaken,
//       user, profile_pic_url 
//     });

//       // res.status(200).json({ user, profile_pic_url });
//     } catch (error) {
//       console.log(error);
//     }
//   });

// Endpoint to fetch current user details
app.get('/api/current-user', TokenAuthentication, async (req, res) => {
  try {
    const userId = req.user._id; // Extract userId from the token
    if (!userId) {
      console.error('No user ID found in the token');
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const user = await UserData.findById(userId);

    if (!user) {
      console.error(`User not found with ID: ${userId}`);
      return res.status(404).json({ error: 'User not found' });
    }

    // Construct profile picture URL
    let profile_pic_url = `${process.env.API_URL}/profile_picture/${user.originalFileName}`;

    // Check if the profile picture exists
    const profilePicPath = path.join(__dirname, 'profile_picture', user.originalFileName);
    fs.access(profilePicPath, fs.constants.F_OK, async (err) => {
      if (err) {
        console.warn(`Profile picture not found at: ${profilePicPath}`);
        // Use default profile picture if the specific one does not exist
        profile_pic_url = `${process.env.API_URL}/profile_picture/user.png`;
      }


      // Fetch casual leave status for the current month

      const currentDate = new Date();
      const currentMonth = currentDate.getMonth() + 1; // JavaScript months are 0-based
      const currentYear = currentDate.getFullYear();
  
      let leaveYear = user.leaveDetails.find(ld => ld.year === currentYear);
      if (!leaveYear) {
        // Create default year entry if it doesn't exist
        leaveYear = { year: currentYear, months: [] };
        user.leaveDetails.push(leaveYear);
      }
  
      // Check if the month exists within the year
      let leaveMonth = leaveYear.months.find(m => m.month === currentMonth);
      if (!leaveMonth) {
        // Create default month entry if it doesn't exist
        leaveMonth = { month: currentMonth, clTaken: false, totalNumberOfLeavesTaken: 0 };
        leaveYear.months.push(leaveMonth);
      }
  
      // Save changes to the database if any new entries were added
      await user.save();
      const clTaken = leaveMonth.clTaken;

      // Respond with user details, profile picture URL, and casual leave status
      res.status(200).json({
        user,  
        clTaken,
        profile_pic_url
      });
    });
  } catch (error) {
    console.error('Error fetching user details:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.put('/api/userdata-update/:id',  TokenAuthentication, Admin_HR_Authentication, async(req, res)=>{
  const {id} = req.params;
  const updatedUser = req.body.updatedUser

  try {
    const user = await UserData.findById(id);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    user.name = updatedUser.name
    user.email = updatedUser.email
    user.role = updatedUser.role
    user.designation = updatedUser.designation
    user.password = updatedUser.password

    await user.save()
    res.status(200).json({ message: "User info updated successfully"})

  } catch (err) {
    console.log(err);
    return res.status(500).json({ message: "Error occurred when trying to update user data" });
  }
})

app.delete('/api/userdata-delete/:id',  TokenAuthentication, Admin_HR_Authentication, async (req, res) => {
  const { id } = req.params;
  
  if (!isValidObjectId(id)) {
    return res.status(400).json({ message: "Invalid user ID" });
  }

  try {
    const user = await UserData.findByIdAndDelete(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ message: "User deleted successfully" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Error occurred when trying to delete user data" });
  }
});

const Certificate_Storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'medical_certificate/'); 
  },
  filename: (req, file, cb) => {
    const originalFileName = file.originalname;
    cb(null, originalFileName); 
  }
});

const medical_certificate = multer({ storage: Certificate_Storage });


const uploadDir = path.join(__dirname, 'medical_certificate');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}


// const workAlternationSchema = new Schema({
//   day: String,
//   entries: [{
//     work: String,
//     employee_id: String
//   }]
// });







const transporter = nodemailer.createTransport({
  service: 'Gmail', // or your email service
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS

    // user: "jeevanantham.iro@gmail.com",
    // pass: "jltllwuzvwypcbqu",
  },
  tls: {
    rejectUnauthorized: false
  }
});


const generateTableRows =  (altUsers, formData, workAlternationData,  leave_id, user_id, confirmation = false) => {
  let rows = '';

  const addRow = (label, value) => {
    if (value && value !== 'undefined' && value !== 'null') {
      rows += `<tr><td><strong>${label}:</strong></td><td colSpan=2>${value}</td></tr>`;
    }
  };

  addRow('Name', formData.user_name);
  if(confirmation) addRow('Leave Type', formData.leavetype);
  addRow('Number of Days', formData.numberOfDays);
  addRow('Leave Session', formData.leaveSession);
  addRow('From Date', formData.fromDate);
  addRow('To Date', formData.toDate);
  addRow('Permission', formData.permission);
  if(confirmation) addRow('Reason', formData.reason);
    // Formatting Work Alternation Data as a list

    if (workAlternationData) {
      let tableRows = '';
    
      workAlternationData.map(entry =>{
        const workAlternations = entry.workAlternations
        const day  = `Day-${entry.dayNumber}`
        workAlternations.map((entry, index) => {
          

          if(!altUsers[entry.employee_id]) return;

          if (index === 0) {
            tableRows += `<tr><td rowSpan='${workAlternations.length}'>${day}</td><td>${entry.work}</td><td>${altUsers[entry.employee_id]}</td></tr>`;
            return
          }
          tableRows += `<tr><td>${entry.work}</td><td>${altUsers[entry.employee_id]}</td></tr>`
        });
      })

      rows += `<tr><td colSpan="3"><strong>Work Alternation Data:</strong></td></tr>`;
      rows += tableRows
    }
    if(confirmation){
      rows += `
      
      <tr>
          <td colSpan="3" style={{ textAlign: "center", padding: 10, borderRadius: 10 }}>
              <div style="text-align:center;">
                  <a href="${process.env.API_URL}/leave-response/accepted/${leave_id}/${user_id}" style='display: inline-block; margin-right: 1rem; background-color: #83D475; color: black; padding: 0.8rem 1.5rem; text-align:center; font-weight:bold;  text-decoration: none'>Accept</a>
                  <a href="${process.env.API_URL}/leave-response/rejected/${leave_id}/${user_id}" style='display: inline-block; background-color:#f07470; color: white; padding: 0.8rem 1.5rem; text-decoration: none; text-align:center; font-weight:bold; '>Reject</a>
              </div>
          </td>
      </tr>      
      `
    }
    
  return rows;
};

app.get('/leave-response/:response/:leave_id/:user_id', async (req, res) =>{
  const response = req.params.response
  const leave_id = req.params.leave_id
  const user_id = req.params.user_id

  const leaveApplication = await LeaveApplication.findById(leave_id)
  console.log('>>>>>>>>>>>', leaveApplication)
  if(!leaveApplication || leaveApplication.user_id.toString() !== user_id) return res.status(404).json({message: 'invalid data2'})

  const user = await UserData.findById(user_id)
  if(!user) return res.status(404).json({message: 'invalid data1'})

      try {
    leaveApplication.status = response
    leaveApplication.save()

    const mailOptions_1 = {
      from: `"Leave Management System" <${process.env.EMAIL_USER}>`,
      to: [user.email] ,
      subject: `Leave Application ${response.toUpperCase()}`,
      html: `<p>Your leave application has been ${response}.</p>`
    };

    transporter.sendMail(mailOptions_1, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });

    const mailOptions_3 = {
      from: `"Leave Management System" <${process.env.EMAIL_USER}>`,
    // to: ['smys375@gmail.com' ,'jennifer.raj@gmail.com','vijitha.ejesra@gmail.com' ],
      to: [user.email] ,
      subject: `Leave Application ${response.toUpperCase()}`,
      html: `<p>The leave application submitted by ${user.name} has been ${response}.</p>`
    };

    transporter.sendMail(mailOptions_3, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });



    if (response === 'rejected' && leaveApplication.leavetype === 'CL-Casual Leave') {const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1; // JavaScript months are 0-based
    const currentYear = currentDate.getFullYear();

    let leaveYear = user.leaveDetails.find(ld => ld.year === currentYear);
    if (!leaveYear) {
      // Create default year entry if it doesn't exist
      leaveYear = { year: currentYear, months: [] };
      user.leaveDetails.push(leaveYear);
    }

    // Check if the month exists within the year
    let leaveMonth = leaveYear.months.find(m => m.month === currentMonth);
    if (!leaveMonth) {
      // Create default month entry if it doesn't exist
      leaveMonth = { month: currentMonth, clTaken: false, totalNumberOfLeavesTaken: 0 };
      leaveYear.months.push(leaveMonth);
    }
    leaveMonth.clTaken = false
    // Save changes to the database if any new entries were added
    await user.save();
    }

    if(response === 'accepted'){
      const workAlternationData = JSON.parse(leaveApplication.workAlternationData)


      let alternationEmailIds = await Promise.all(workAlternationData.map(async entry => {
      
      const workAlternations = entry.workAlternations;
      const emails = await Promise.all(workAlternations.map(async alt => {
        if(!alt.employee_id) return;
        const res = await UserData.findById(alt.employee_id).select("email");
        return res && res.email ? res.email : null;
        }));
        return emails.filter(email => email !== null); // Remove null values
        }));
        
        alternationEmailIds = [...new Set(alternationEmailIds.flat())];

        if(alternationEmailIds.length > 0){
        const res_ = await UserData.find({_id: {$ne: user._id}}).select('_id, name');
        const altUsers = res_.reduce((acc, user) => {
          acc[user._id] = user.name;
          return acc;
      }, {});
    
      const mailOptions = {
        from: `"Leave Management System" <${process.env.EMAIL_USER}>`,
        // to: [...alternationEmailIds, 'vijitha.ejesra@gmail.com'] ,
        to: ['jeevanantham.iro@gmail.com','vinyl.ejesra@gmail.com'] ,
        subject: 'Work Alternation Assigned',
        html: `
        <p>Work alternation assigned. Details:</p>
        <table border="1" cellpadding="10" cellspacing="0" style="border-collapse: collapse;border: 1px solid black;padding: 1rem">
        
          ${generateTableRows(altUsers, {  
            user_name: leaveApplication.user_name,
            leavetype: leaveApplication.leavetype,
             numberOfDays: leaveApplication.numberOfDays,
             leaveSession: leaveApplication.leaveSession,
              fromDate: leaveApplication.fromDate, 
             toDate: leaveApplication.toDate,
              permission: leaveApplication.permission,
              reason: leaveApplication.reason,}, 
              workAlternationData, 
              leaveApplication._id,  user._id, false)}
        </table>
      `
      };
  
      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error('Error sending email:', error);
        } else {
          console.log('Email sent:', info.response);
        }
      });
    }
  }

    res.status(200).send("Leave Application: " + response.toUpperCase())
    
    } catch (error) {
      console.log('>>>>>>>>>>>', error)
    res.status(500).json({message: "failed to save changes"})
  }
})


app.post('/api/leave-applications',  TokenAuthentication, medical_certificate.single('file'), async (req, res) => {
const user = req.user
  try {
    const workAlternationData = JSON.parse(req.body.workAlternationData);
    // FORMAT of workAlternations - Reference
    // workAlternations.map((dayWork, index) => ({
    //   dayNumber: index + 1,
    //   workAlternations: dayWork,
    // }))
      
    const formData = {
      user_id: user._id,
      user_name: user.name,
      leavetype: req.body.leavetype || "",
      numberOfDays: req.body.numberOfDays || "",
      leaveSession: req.body.leaveSession || "",
      fromDate: req.body.fromDate || "",
      toDate: req.body.toDate || "",
      permission: req.body.permission || "",
      reason: req.body.reason || "",
      workAlternationData: JSON.stringify(workAlternationData),
      // file: req.file ? req.file.path : '',
      status: "Pending"
    };

    if(req.file) formData.file = req.file.path;

    const leaveApplication = new LeaveApplication(formData);
    await leaveApplication.save();
    
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1; // JavaScript months are 0-based
    const currentYear = currentDate.getFullYear();

    let leaveYear = user.leaveDetails.find(ld => ld.year === currentYear);
    if (!leaveYear) {
      // Create default year entry if it doesn't exist
      leaveYear = { year: currentYear, months: [] };
      user.leaveDetails.push(leaveYear);
    }

    // Check if the month exists within the year
    let leaveMonth = leaveYear.months.find(m => m.month === currentMonth);
    if (!leaveMonth) {
      // Create default month entry if it doesn't exist
      leaveMonth = { month: currentMonth, clTaken: true, totalNumberOfLeavesTaken: 0 };
      leaveYear.months.push(leaveMonth);
    }
    leaveMonth.clTaken = true
    // Save changes to the database if any new entries were added
    await user.save();


    const res_ = await UserData.find({_id: {$ne: user._id}}).select('_id, name');
    const altUsers = res_.reduce((acc, user) => {
      acc[user._id] = user.name;
      return acc;
  }, {});




    

  
  const mailOptions = {
    from: `"Leave Management System" <${process.env.EMAIL_USER}>`,
    to: ['jeevanantham.iro@gmail.com','vinyl.ejesra@gmail.com'],
    // to: ['smys375@gmail.com' ,'jennifer.raj@gmail.com','vijitha.ejesra@gmail.com' ],
    subject: 'New Leave Application Submitted',
    html: `
    <p>A new leave application has been submitted. Details:</p>
    <table border="1" cellpadding="10" cellSpacing="0">
      ${generateTableRows(altUsers, formData, workAlternationData, leaveApplication._id, user._id, true)}
    </table>
  `
  };

  if(req.file){
    mailOptions.attachments = {filename: req.file.originalname, path: req.file.path}
  }

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error('Error sending email:', error);
    } else {
      console.log('Email sent:', info.response);
    }
  });

  

  const mailOptions_2 = {
    from: `"Leave Management System" <${process.env.EMAIL_USER}>`,
    to: user.email,
    subject: 'New Leave Application Received',
    html: `<p>We have received your leave application. We will update the status of your application soon.</p>`
  };

  transporter.sendMail(mailOptions_2, (error, info) => {
    if (error) {
      console.error('Error sending email:', error);
    } else {
      console.log('Email sent:', info.response);
    }
  });

    res.json({ message: 'Form submitted successfully', data: formData });
  } catch (error) {
    console.error('Error processing form data:', error);  
    res.status(400).json({ error: 'Invalid form data' });
  }
});

// GET endpoint to retrieve leave applications
app.get('/api/all-leave-applications',  TokenAuthentication, Admin_HR_Authentication, async (req, res) => {
  try {

    const leaveApplications = await LeaveApplication.find().populate("user_id", "name emp_id");
    //  const employees = await UserData.find().select("name , emp_id")
     
    // console.log('>>>>>>>>>>>', employees)
    // res.json({leaveApplications, employees} );
    res.json({leaveApplications, } );
  } catch (error) {
    console.error('Error retrieving leave applications:', error);
    res.status(500).json({ error: 'Failed to retrieve leave applications' });
  }
});



// GET endpoint to retrieve leave applications for Generate report
// app.get('/api/all-leave-applications-generate-report',  TokenAuthentication, Admin_HR_Authenticatleave-responseion, async (req, res) => {
//   try {

//     const leaveApplications = await LeaveApplication.find().populate("user_id", "name emp_id");
//     //  const employees = await UserData.find().select("name , emp_id")
     
//     // console.log('>>>>>>>>>>>', employees)
//     // res.json({leaveApplications, employees} );
//     res.json({leaveApplications } );
//   } catch (error) {
//     console.error('Error retrieving leave applications:', error);
//     res.status(500).json({ error: 'Failed to retrieve leave applications' });
//   }
// });


app.get('/api/all-leave-applications-generate-report', TokenAuthentication, Admin_HR_Authentication, async (req, res) => {
  try {
    const leaveApplications = await LeaveApplication.find().populate("user_id", "name emp_id");

    console.log('>>>>>>>>>>>', leaveApplications)
    // Group leave applications by emp_id and leaveType
    const groupedApplications = leaveApplications.reduce((acc, application) => {
      const empId = application.user_id.emp_id;
      const leaveType = application.leavetype;

      // Initialize emp_id group if it doesn't exist
      if (!acc[empId]) {
        acc[empId] = {
          emp_id: empId,
          user_name: application.user_id.name,
          leaveTypes: {} // Subgroup for leave types
        };
      }

      // Initialize leaveType group if it doesn't exist
      if (!acc[empId].leaveTypes[leaveType]) {
        acc[empId].leaveTypes[leaveType] = {
          leaveType: leaveType,
          totalDays: 0, // Initialize total days for this leave type
          applications: []
        };
      }

      // Add application details and update total number of days
      acc[empId].leaveTypes[leaveType].applications.push({
        applicationId: application._id,
        startDate: application.fromDate,
        endDate: application.toDate,
        numberOfDays: application.numberOfDays,
        leaveSession: application.leaveSession,
        permission: application.permission
      });
      
      acc[empId].leaveTypes[leaveType].totalDays +=  Number(application.numberOfDays);

      return acc;
    }, {});

    // Convert the grouped object to an array of employees and their leave types
    const result = Object.values(groupedApplications).map(employee => ({
      emp_id: employee.emp_id,
      user_name: employee.user_name,
      leaveTypes: Object.values(employee.leaveTypes) // Convert leaveTypes object to array
    }));

    res.json(result);

    console.log(JSON.stringify(result, null, 2));

  } catch (error) {
    console.error('Error retrieving leave applications:', error);
    res.status(500).json({ error: 'Failed to retrieve leave applications' });
  }
});

app.delete('/leaveApplications/:id',  TokenAuthentication, Admin_HR_Authentication, async (req, res) => {
  try {
    const { id } = req.params;
    await LeaveApplication.findByIdAndDelete(id);
    res.status(200).send({ message: 'Leave application deleted successfully' });
  } catch (error) {
    res.status(500).send({ message: 'Failed to delete leave application' });
  }
});


app.listen(port, '::' , () => console.log(`Server running on port:${port}`));
