const mongoose = require("mongoose");

const userDataSchema = new mongoose.Schema({
  name: String,
  company: String,
  email: String,
  password: String,
  role: String,
  emp_id: String,
  designation: String,
  date_of_joining: String,
  leaveDetails: [{
    year: Number,
    months: [{
      month: Number,
      clTaken: {
        type: Boolean, default: false
      },
      totalNumberOfLeavesTaken: {
        type: Number, default: 0
      },
    }]
  }],
  originalFileName: String,
  // createdAt: { type: Date, default: Date.now }
  createdAt: String,
});

module.exports = mongoose.model("UserData", userDataSchema);
