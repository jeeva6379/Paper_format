const mongoose = require("mongoose");

const leaveApplicationSchema = new mongoose.Schema({
    user_id: {type: mongoose.Schema.Types.ObjectId, ref:"UserData", },
    user_name: String,
    leavetype: String,
    numberOfDays: String,
    leaveSession: String,
    fromDate: String,
    toDate: String,
    permission: String,
    reason: String,
    // workAlternationData: [workAlternationSchema],
    workAlternationData: String,
    file: String,
    status: String,
  });

module.exports = mongoose.model('LeaveApplication', leaveApplicationSchema);