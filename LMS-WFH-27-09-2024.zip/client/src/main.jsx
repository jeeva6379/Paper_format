
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./Login.jsx";
import LeaveForm from "./LeaveForm.jsx";
import Dashboard from "./components/Dashboard.jsx";
import CreateUser from "./admin/CreateUser.jsx";
import Manageusers from "./admin/Manageusers.jsx";
import LeaveApplications from "./admin/LeaveApplications.jsx";
import GenerateReport from "./admin/GenerateReport.jsx";
import Layout from "./Layout.jsx";

import "bootstrap/dist/css/bootstrap.css";
import "./main.css";

// import App from './App.jsx'

export default  function App(){

return(
  <>
  <BrowserRouter>
    <Routes>
        <Route index element={<Login/>}/>
        <Route element={<Layout/>}>
        <Route path="apply-leave" element={<LeaveForm />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="create-user" element={<CreateUser />} />
        <Route path="manage-user" element={<Manageusers />} />
        <Route path="leave-applications" element={<LeaveApplications />} />
        <Route path="generate-report" element={<GenerateReport />} />
        </Route>
    </Routes>
  </BrowserRouter>
  </>
)

}
ReactDOM.createRoot(document.getElementById("root")).render(<App/>);