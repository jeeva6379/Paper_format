import { useState, useEffect } from "react";

import axios from "axios";
import { useNavigate } from "react-router-dom";

import "./LeaveApplications.css"; 

const LeaveApplications = () => {
  const API_URL = import.meta.env.VITE_API_URL;
  const navigate = useNavigate();
  const [leaveApplications, setLeaveApplications] = useState([]);
  const [workAlternationEmployees, setWorkAlternationEmployees] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const role = localStorage.getItem("role");
    if (role !== "Admin" && role !== "HR") navigate("/");
  }, []);

  const fetchLeaveApplications = async () => {  
    try {
      const response = await axios.get(`${API_URL}/api/all-leave-applications`);  
      setLeaveApplications(response.data.leaveApplications);
      console.log("data",response.data.leaveApplications);  
      setWorkAlternationEmployees(response.data.employees);
      console.log("Employee_data",response.data.employees);  

    } catch (error) {
      console.error("Error fetching leave applications:", error);
      setError("Failed to fetch leave applications.");  
      if (error?.response?.status === 401) navigate("/");
    }
  };

  // const workAlternation = (data) => {
  //   const jdata = Object.values(JSON.parse(data));
  //   let formattedData = "<div>";
  //   jdata.map((entry, index) => {
  //     const day = entry.dayNumber;
  //     formattedData += `<div style="${index > 0 && "margin-top:.7rem"}">
  //     <strong>Day - ${day}</strong></div><div style='display:grid;grid-template-columns: 1fr 1fr;column-gap:1rem;'>`;

  //     // console.log('>>>>>>>>>>>', entry.workAlternations)

      
  //     entry.workAlternations.map(item => {
  //       const res = workAlternationEmployees.filter(employee => employee._id === item.employee_id);

  //       if (item.length > 0) {
  //         formattedData += `<div>${item.work}</div><div>${res[0].name}</div>`;
  //       } else {
  //         formattedData += `<div>${item.work}</div><div>Unknown</div>`;
  //       }
  //     });
  //     formattedData += `</div>`;
  //   });
  //   formattedData += "</div>";
  //   return formattedData;
  // };

  const workAlternation = (data) => {
    const jdata = Object.values(JSON.parse(data));
    let formattedData = "<div>";
  
    jdata.map((entry, index) => {
      const day = entry.dayNumber;
      formattedData += `<div style="${index > 0 && 'margin-top:.7rem'}"><strong>Day - ${day}</strong></div><div style='display:grid;grid-template-columns: 1fr 1fr;column-gap:1rem;'>`;
      
      entry.workAlternations.map(item => {
        // Ensure workAlternationEmployees is defined and has data
        if (workAlternationEmployees && workAlternationEmployees.length > 0) {
          const res = workAlternationEmployees.filter(employee => employee._id == item.employee_id);
  
          if (res.length > 0) {
            formattedData += `<div>${item.work}</div><div>${res[0].name}</div>`;
          } else {
            formattedData += `<div>${item.work}</div><div>Unknown</div>`;
          }
        } else {
          formattedData += `<div>${item.work}</div><div>Unknown</div>`;
        }
      });
      
      formattedData += `</div>`;
    });
  
    formattedData += "</div>";
    return formattedData;
  };
  

  useEffect(() => {
    fetchLeaveApplications();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/leaveApplications/${id}`);
      setLeaveApplications(leaveApplications.filter((app) => app._id !== id));
    } catch (error) {
      setError("Failed to delete leave application.");
      if (error?.response?.status === 401) navigate("/");
    }
  };

  return (
    <div>
      <h3>List of leave applications</h3>
      {error && <p className="error-message">{error}</p>}
      <div className="table-container">
        <table className="leave-table table-striped table-light table small">
          <thead>
            <tr>
              <th rowSpan={2}>Name</th><th rowSpan={2}>Leave Type</th>
              <th rowSpan={2}>Number of Days</th>
              <th rowSpan={2}>Leave Session</th>       
              <th rowSpan={2} >From Date</th>
              <th rowSpan={2} >To Date</th>
              {/* <th rowSpan={2}>Permission</th> */}
              <th rowSpan={2}>Reason</th>
              <th colSpan={2}>Work Alternation Data</th>
              <th rowSpan={2}>Medical Certificate</th>
              <th rowSpan={2}>Status</th>
              <th rowSpan={2}>Actions</th>
            </tr>
            <tr><th>Work</th><th>Altered to</th></tr>
          </thead>
          <tbody>
            {leaveApplications.map((application) => (
              <tr key={application._id}>
                <td>{application.user_name}</td>
                <td>{application.leavetype}</td>
                <td>{application.numberOfDays}</td>
                <td>{application.leaveSession || "-"}</td>
                <td >{application.fromDate}</td>
                <td >{application.toDate}</td>
                {/* <td>{application.permission}</td> */}
                <td>{application.reason}</td>
                <td colSpan={2} dangerouslySetInnerHTML={{__html: workAlternation(application.workAlternationData),}}></td>
                <td className="text-center"><a href={`${API_URL}/${application.file}`} target="_blank" rel="noopener noreferrer">View</a></td>
                <td>{application.status}</td>
                <td><button onClick={() => handleDelete(application._id)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeaveApplications;

