import { useEffect, useState } from "react";

import { Form  } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import axios from "axios";
import { useNavigate } from "react-router-dom";

import "./CreateUser.css";


const CreateUser = () => {
  const API_URL = import.meta.env.VITE_API_URL;
  const navigate = new useNavigate()
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [company, setCompany] = useState("");
  const [errors, setErrors] = useState({});
  const [emp_id, setEmpId] = useState("");
  const [name, setName] = useState("");
  const [designation, setDesignation] = useState("");
  const [date_of_joining, setDate_of_Joining] = useState("");
  const [Uploadimage, setUploadImage] = useState("");
  const [displayUploadedImage, setDisplayUploadedImage] = useState("");

  useEffect(() => {
    const role = localStorage.getItem('role');
    if(role !== "Admin" && role !== "HR") navigate('/')
  }, []);

  const resetForm = () => {
    setEmail("");
    setPassword("");
    setRole("");
    setCompany("");
    setEmpId("");
    setName("");
    setDesignation("");
    setDate_of_Joining("");
    setUploadImage("");
    document.getElementById("input-profile-pic").value = "";
    setDisplayUploadedImage("");
    setErrors({});
  };

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // const handleShowPassword = () => {
  //   setShowPassword(!showPassword);
  // };

  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  const ComapanyChange = (e) => {
    const selectedCompany = e.target.value;

    setCompany(selectedCompany);

    // Set employee ID based on the selected company
    let generatedEmpId = "";
    if (selectedCompany === "IRO") {
      generatedEmpId = "IRO-";
    } else if (selectedCompany === "EJESRA") {
      generatedEmpId = "EJ-";
    } else if (selectedCompany === "CONFYY") {
      generatedEmpId = "CFY-";
    }

    setEmpId(generatedEmpId);
  };

  const EmployeeId = (e) => {
    setEmpId(e.target.value);
  };

  const handleDesignationChange = (e) => {
    setDesignation(e.target.value);
  };

  const handleDateOfJoiningChange = (e) => {
    setDate_of_Joining(e.target.value);
  };

  const handleUploadImage = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadImage(file);

      const maxSize = 2 * 1024 * 1024; // 2 MB in bytes

      if (file.size > maxSize || !file.type.startsWith("image/")) {
        return setDisplayUploadedImage(null);
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setDisplayUploadedImage(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setDisplayUploadedImage(null);
      // setUploadImage(null)
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = {};

    // Validate email
    if (!email) {
      validationErrors.email = "Email is required";
    }

    // Validate password
    if (!password) {
      validationErrors.password = "Password is required";
    } else if (password.length < 8) {
      validationErrors.password = "Password must be at least 8 characters long";
    }

    // Validate role
    if (!role) {
      validationErrors.role = "Role is required";
    }
    if (!company) {
      validationErrors.company = "Company is required";
    }

    if (!emp_id) {
      validationErrors.emp_id = "Please enter the employee_id";
    }

    if (!name) {
      validationErrors.name = "Please enter your name";
    }

    if (!designation) {
      validationErrors.designation = "Please enter your designation";
    }
    if (!date_of_joining) {
      validationErrors.date_of_joining = "Please fill the date_of_joining";
    }
    if (!Uploadimage) {
      validationErrors.Uploadimage = "Please upload profile picture";
    } else {
      const maxSize = 2 * 1024 * 1024; // 2 MB in bytes
      if (Uploadimage.size > maxSize) {
        validationErrors.Uploadimage =
          "File size exceeds 2 MB. Please choose a smaller file.";
        setDisplayUploadedImage(null);
      } else if (!Uploadimage.type.startsWith("image/")) {
        validationErrors.Uploadimage = "Only image files are allowed.";
        setDisplayUploadedImage(null);
      }
    }

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("company", company);

    formData.append("email", email);
    formData.append("password", password);
    formData.append("role", role);
    formData.append("emp_id", emp_id);
    formData.append("designation", designation);
    formData.append("date_of_joining", date_of_joining);
    formData.append("Uploadimage", Uploadimage);

    try {
      // Send HTTP POST request
      const response = await axios.post(`${API_URL}/api/userdata`, formData, {
        // headers: { "Content-Type": "application/json" },
        headers: { 'Content-Type': 'multipart/form-data' }, 

      });

      if (response.status === 200) {
        alert(response.data.message);
        resetForm();
        window.location.href='/manage-user'
      }
    } catch (error) {
      console.error("There was an error creating user:", error.response.data);
      if (error?.response?.status === 401) navigate("/")
    }
  };

  return (
      <>
            <Form onSubmit={handleSubmit} className="Form-bg ">
              <h5 className="mb-4 text-center ">Create New User</h5>
              <div className="d-lg-flex">
                <div className="col-xl-6 left-section">
                  <Form.Group className="mb-3" controlId="formGroupName">
                    <Form.Label className="label_">Name</Form.Label>
                    <Form.Control
                      type="text"
                      className=" input-text"
                      value={name}
                      onChange={handleNameChange}
                      isInvalid={!!errors.name}
                    />
                    <Form.Control.Feedback className="err-msg" type="invalid">
                      {errors.name}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-4 " controlId="formGroupCompany">
                    <Form.Label className="label_">Company</Form.Label>
                    <Form.Control
                      as="select"
                      className=" input-select"
                      value={company}
                      onChange={ComapanyChange}
                      isInvalid={!!errors.company}
                    >
                      <option value="" disabled>
                        {/* Select Company */}
                      </option>
                      <option value="IRO">IRO</option>
                      <option value="EJESRA">EJESRA</option>
                      <option value="CONFYY">CONFYY</option>
                    </Form.Control>

                    <Form.Control.Feedback className="err-msg" type="invalid">
                      {errors.company}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-3 " controlId="formGroupEmpId">
                    <Form.Label className="label_">Employee ID</Form.Label>
                    <Form.Control
                      type="text"
                      value={emp_id}
                      className=" input-text"
                      onChange={EmployeeId}
                      isInvalid={!!errors.emp_id}
                    />
                    {errors.emp_id && (
                      <Form.Control.Feedback className="err-msg" type="invalid">
                        {errors.emp_id}
                      </Form.Control.Feedback>
                    )}
                  </Form.Group>

                  <Form.Group
                    className="mb-3 "
                    controlId="formGroupDesignation"
                  >
                    <Form.Label className="label_">Designation</Form.Label>
                    <Form.Control
                      type="text"
                      className=" input-text"
                      value={designation}
                      onChange={handleDesignationChange}
                      isInvalid={!!errors.designation}
                    />
                    <Form.Control.Feedback className="err-msg" type="invalid">
                      {errors.designation}
                    </Form.Control.Feedback>
                  </Form.Group>
                  <Form.Group
                    className="mb-3 "
                    controlId="formGroupDateOfJoining"
                  >
                    <Form.Label className="label_">Date of Joining</Form.Label>
                    <Form.Control
                      type="text"
                      className=" input-text"
                      value={date_of_joining}
                      onChange={handleDateOfJoiningChange}
                      isInvalid={!!errors.date_of_joining}
                    />
                    <Form.Control.Feedback className="err-msg" type="invalid">
                      {errors.date_of_joining}
                    </Form.Control.Feedback>
                  </Form.Group>
                </div>
                <div className="col-xl-6 right-section">
                  <Form.Group className="mb-4 " controlId="formGroupRole">
                    <Form.Label className="label_">Role</Form.Label>
                    <Form.Control
                      as="select"
                      className=" input-select"
                      value={role}
                      onChange={handleRoleChange}
                      isInvalid={!!errors.role}
                    >
                      <option value="" disabled>
                        {/* Select Role */}
                      </option>
                      <option value="Admin">Admin</option>
                      <option value="HR">HR</option>
                      <option value="Employee">Employee</option>
                    </Form.Control>

                    <Form.Control.Feedback className="err-msg" type="invalid">
                      {errors.role}
                    </Form.Control.Feedback>
                    
                  </Form.Group>

                  <Form.Group className="mb-3" controlId="formGroupEmail">
                    <Form.Label className="label_">Email address</Form.Label>
                    <Form.Control
                      type="email"
autoComplete="off"
                      className=" input-text"
                      value={email}
                      onChange={handleEmailChange}
                      isInvalid={!!errors.email}
                    />
                    <Form.Control.Feedback className="err-msg" type="invalid">
                      {errors.email}
                    </Form.Control.Feedback>
                  </Form.Group>
                  <Form.Group className="mb-3" controlId="formGroupPassword">
                    <Form.Label className="label_">Password</Form.Label>
                    <Form.Control
                      className="my-auto mr-3  input-text"
                      //   type={showPassword ? "text" : "password"} // Toggle password visibility
                      type="password"
                      autoComplete="new-password"
                      value={password}
                      onChange={handlePasswordChange}
                      isInvalid={!!errors.password}
                    />
                    <Form.Control.Feedback
                      className="err-msg-pass my-auto ml-3"
                      type="invalid"
                    >
                      {errors.password}
                    </Form.Control.Feedback>

                    {/* <Form.Check
              className="my-auto ml-3"
              type="checkbox"
              label={<FontAwesomeIcon icon={showPassword ? faEyeSlash : faEye}
               />}
              onChange={handleShowPassword}
            /> */}
                  </Form.Group>

                  <Form.Group controlId="formGroupProfilePic">
                    <Form.Label className="label_">
                      Upload profile picture
                    </Form.Label>
                    <Form.Control
                      className="input-file mb-1"
                      id="input-profile-pic"
                      type="file"
                      accept="image/*"
                      onChange={handleUploadImage}
                      isInvalid={!!errors.Uploadimage}
                    />
                    <Form.Control.Feedback
                      className="err-msg-file"
                      type="invalid"
                    >
                      {errors.Uploadimage}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <div style={{ height: "60px" }}>
                    {displayUploadedImage && (
                      <img
                        src={displayUploadedImage}
                        alt=""
                        style={{ height: "60px", maxWidth: "100%" }}
                      />
                    )}
                  </div>

                  <Form.Group className="mb-3 mt-3 text-center">
                    <Button
                      className="btn btn-dark btn-block px-4"
                      style={{ borderRadius: 0 }}
                      type="submit"
                    >
                      Create User
                    </Button>
                  </Form.Group>
                </div>
              </div>
            </Form>
          </>
  );
};

export default CreateUser;
