// import { useState, useEffect } from "react";

// import axios from "axios";
// import { useNavigate } from "react-router-dom";

// import "./GenerateReport.css";

// const GenerateReport = () => {
//   const API_URL = import.meta.env.VITE_API_URL;
//   const navigate = useNavigate();
//   const [leaveData, setLeaveData] = useState([]);
//   const [error, setError] = useState(null);
//   const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
//   const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

//   useEffect(() => {
//     const role = localStorage.getItem("role");
//     if (role !== "Admin" && role !== "HR") {
//       navigate("/");
//     }
//   }, [navigate]);

//   const fetchLeaveApplications = async () => {
//     try {
//       const response = await axios.get(
//         `${API_URL}/api/all-leave-applications-generate-report`
//       );
//       const data = response.data || [];

// const filteredData = data.map(leave => ({
//     ...leave,
//     leaveTypes: leave.leaveTypes
//       .map(l => ({
//         ...l,
//         applications: l.applications.filter(a => {
//           const [, month, year] = a.startDate.split('-');
//           return selectedMonth === Number(month) && selectedYear === Number(year);
//         })
//       }))
//       .filter(l => l.applications.length > 0) // Filter out leaveTypes with no matching applications
//   }))
//   .filter(leave => leave.leaveTypes.length > 0); 

//       setLeaveData(filteredData);
//       console.log("Fetched Leave Data:", data);
//       console.log("filtered Leave Data:", filteredData);
//     } catch (error) {
//       console.error("Error fetching leave data:", error);
//       setError("Failed to fetch leave data.");
//       if (error?.response?.status === 401) navigate("/");
//     }
//   };

//   useEffect(() => {
//     fetchLeaveApplications();
//   }, [selectedMonth, selectedYear]);

//   const handleMonthChange = (event) => {
//     setSelectedMonth(Number(event.target.value));
//   };

//   const handleYearChange = (event) => {
//     setSelectedYear(Number(event.target.value));
//   };

//   const getYearOptions = () => {
//     const currentYear = new Date().getFullYear();
//     const years = [];
//     for (let i = 0; i <= 5; i++) {
//       years.push(currentYear + i);
//     }
//     return years;
//   };

//   const leaveCount = (list, type) => {
//     const filteredList = list.find((l) => l.leaveType === type);
//     return filteredList ? filteredList.applications.reduce((total, a) => total + Number(a.numberOfDays), 0) : '';
//   };

//   return (
//     <div>
//       <h3>List of Leave Applications</h3>
//       {error && <p className="error-message">{error}</p>}
//       <div className="filters">
//         <label htmlFor="month-select">Select Month:</label>
//         <select
//           id="month-select"
//           value={selectedMonth}
//           onChange={handleMonthChange}
//         >
//           {Array.from({ length: 12 }, (_, i) => (
//             <option key={i + 1} value={i + 1}>
//               {new Date(0, i).toLocaleString("default", { month: "long" })}
//             </option>
//           ))}
//         </select>

//         <label htmlFor="year-select">Select Year:</label>
//         <select
//           id="year-select"
//           value={selectedYear}
//           onChange={handleYearChange}
//         >
//           {getYearOptions().map((year) => (
//             <option key={year} value={year}>
//               {year}
//             </option>
//           ))}
//         </select>
//       </div>

//       <div className="table-container">
//         {leaveData.length > 0 ? (
//           <table className="leave-table table-striped table-light table small">
//             <thead>
//               <tr key="">
//                 <th>Emp ID</th>
//                 <th>Name</th>
//                 <th>Number of CL's Availed</th>
//                 <th>Number of LLP's Availed</th>
//                 <th>Number of ML's Availed</th>
//                 <th>Number of WFH's Availed</th>
//                 <th>Number of LP's Availed</th>
//                 <th>Number of EP's Availed</th>
//               </tr>
//             </thead>
//             <tbody>
//               {leaveData.map((employee) => (
//                 <tr key={employee.emp_id} className="employee-section">
//                   <td className="text-left p-3">{employee.emp_id} </td>
//                   <td className="text-left p-3">{employee.user_name}</td>
//                   <td className="text-center p-3">
//                     {leaveCount(employee.leaveTypes, "CL-Casual Leave")}
//                   </td>
//                   <td className="text-center p-3">
//                     {leaveCount(employee.leaveTypes, "Lop-Loss of Pay")}
//                   </td>
//                   <td className="text-center p-3">
//                     {leaveCount(employee.leaveTypes, "ML-Medical Leave")}
//                   </td>
//                   <td className="text-center p-3">
//                     {leaveCount(employee.leaveTypes, "WFH-Work From Home")} 
//                   </td>
//                   <td className="text-center p-3">
//                     {leaveCount(employee.leaveTypes, "LP-Late Permission")}
//                   </td>
//                   <td className="text-center p-3">
//                     {leaveCount(employee.leaveTypes, "EP-Evening Permission")}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         ) : (
//           <p>No leave data available for the selected month.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default GenerateReport;




import { useState, useEffect } from "react";

import axios from "axios";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import "jspdf-autotable";

import "./GenerateReport.css";

const GenerateReport = () => {
  const API_URL = import.meta.env.VITE_API_URL;
  const navigate = useNavigate();
  const [leaveData, setLeaveData] = useState([]);
  const [error, setError] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => {
    const role = localStorage.getItem("role");
    if (role !== "Admin" && role !== "HR") {
      navigate("/");
    }
  }, [navigate]);

  const fetchLeaveApplications = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/all-leave-applications-generate-report`);
      const data = response.data || [];
      console.log('leaveSession', data);

      const filteredData = data
        .map((leave) => ({
          ...leave,
          leaveTypes: leave.leaveTypes
            .map((l) => ({
              ...l,
              applications: l.applications.filter((a) => {
                const [, month, year] = a.startDate.split("-");
                return selectedMonth === Number(month) && selectedYear === Number(year);
              }),
            }))
            .filter((l) => l.applications.length > 0),
        }))
        .filter((leave) => leave.leaveTypes.length > 0);

      const sortedData = filteredData.sort((a, b) => a.emp_id.localeCompare(b.emp_id));
      setLeaveData(sortedData);
    } catch (error) {
      console.error("Error fetching leave data:", error);
      setError("Failed to fetch leave data.");
      if (error?.response?.status === 401) navigate("/");
    }
  };

  useEffect(() => {
    fetchLeaveApplications();
  }, [selectedMonth, selectedYear]);

  const handleMonthChange = (event) => {
    setSelectedMonth(Number(event.target.value));
  };

  const handleYearChange = (event) => {
    setSelectedYear(Number(event.target.value));
  };

  const getYearOptions = () => {
    const currentYear = new Date().getFullYear();
    return Array.from({ length: 6 }, (_, i) => currentYear + i);
  };

  const leaveCount = (list, type) => {
    const filteredList = list.find((l) => l.leaveType === type);
    if (!filteredList) return { totalDays: "", leaveDates: "", periods: "" };

    const totalDays = filteredList.applications.reduce((total, a) => total + Number(a.numberOfDays), 0);

    // const leaveDates = filteredList.applications.map((a) => a.startDate).join(", ");
    const leaveDates ="";
    const periods = filteredList.applications.map((a) => {

let title = a.endDate ?  `${a.startDate} to ${a.endDate}` : a.startDate
       title += a.leaveSession ? ` ${a.leaveSession}` : ''

    return title;

    }).join(", ");

    // const leaveDates = filteredList.applications.map((a) => a.startDate).join(", ");
    // const periods = filteredList.applications.map((a) => `${a.startDate} to ${a.endDate}`).join(", ");

    return { totalDays, leaveDates, periods };
  };



  const downloadPDF = () => {
    const doc = new jsPDF("landscape"); // Set PDF orientation to landscape
  
    // Add Google Fonts Poppins
    doc.setFont("Poppins", "normal");
    doc.setFontSize(16);
  
    // Get the selected month name
    const monthName = new Date(selectedYear, selectedMonth - 1).toLocaleString("default", { month: "long" });
  
    const tableColumn = [
      "Emp ID",
      "Name",
      "Number of CL's Availed",
      "Number of LLP's Availed",
      "Number of ML's Availed",
      "Number of WFH's Availed",
      "Number of LP's Availed",
      "Number of EP's Availed",
    ];
    
    const tableRows = leaveData.map((employee) => [
      employee.emp_id,
      employee.user_name,
      leaveCount(employee.leaveTypes, "CL-Casual Leave").totalDays,
      leaveCount(employee.leaveTypes, "Lop-Loss of Pay").totalDays,
      leaveCount(employee.leaveTypes, "ML-Medical Leave").totalDays,
      leaveCount(employee.leaveTypes, "WFH-Work From Home").totalDays,
      leaveCount(employee.leaveTypes, "LP-Late Permission").totalDays,
      leaveCount(employee.leaveTypes, "EP-Evening Permission").totalDays,
    ]);
  
    doc.text(`Leave Report for ${monthName} ${selectedYear}`, 14, 20);
    
    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      theme: "grid",
      headStyles: {
        fillColor: [0, 123, 255],
        textColor: 255,
        fontSize: 12,
        halign: 'center',
      },
      styles: {
        cellPadding: 4,
        fontSize: 10,
        halign: 'center',
        valign: 'middle',
      },
      columnStyles: {
        0: { cellWidth: 25, halign: 'left' },
        1: { cellWidth: 50, halign: 'left' },
        2: { cellWidth: 30 },
        3: { cellWidth: 30 },
        4: { cellWidth: 30 },
        5: { cellWidth: 30 },
        6: { cellWidth: 30 },
        7: { cellWidth: 30 },
      },
    });
  
    // Save the PDF with the month name in the file name
    doc.save(`Leave_report_${monthName}_${selectedYear}.pdf`);
  };
  

  return (
    <div>
      <h3>List of Leave Applications</h3>
      {error && <p className="error-message">{error}</p>}
      {/* <div className="filters">
        <label htmlFor="month-select">Select Month:</label>
        <select id="month-select" value={selectedMonth} onChange={handleMonthChange}>
          {Array.from({ length: 12 }, (_, i) => (
            <option key={i + 1} value={i + 1}>
              {new Date(0, i).toLocaleString("default", { month: "long" })}
            </option>
          ))}
        </select>

        <label htmlFor="year-select">Select Year:</label>
        <select id="year-select" value={selectedYear} onChange={handleYearChange}>
          {getYearOptions().map((year) => (
            <option key={year} value={year}>
              {year}
            </option>
          ))}
        </select>
        <div className="d-flex justify-content-end bg-light p-2"><div onClick={downloadPDF} className="btn btn-success   pl-5 mb-3">Download PDF</div></div>

      </div> */}


<div className="filters " style={{ padding: '20px', backgroundColor: '#f8f9fa', boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
  <div>
    <label htmlFor="month-select" style={{ marginRight: '10px', fontWeight: 'bold',color:'#333' }}>Select Month:</label>
    <select 
      id="month-select" 
      value={selectedMonth} 
      onChange={handleMonthChange}
      style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ced4da', marginRight: '20px', fontSize: '14px' }}
    >
      {Array.from({ length: 12 }, (_, i) => (
        <option key={i + 1} value={i + 1}>
          {new Date(0, i).toLocaleString("default", { month: "long" })}
        </option>
      ))}
    </select>

    <label htmlFor="year-select" style={{ marginRight: '10px', fontWeight: 'bold',color:'#333'}}>Select Year:</label>
    <select 
      id="year-select" 
      value={selectedYear} 
      onChange={handleYearChange}
      style={{ padding: '5px', borderRadius: '5px', border: '1px solid #ced4da', fontSize: '14px' }}
    >
      {getYearOptions().map((year) => (
        <option key={year} value={year}>
          {year}
        </option>
      ))}
    </select>
  </div>

  <div style={{ marginLeft: '20px' }}>
    <div 
      onClick={downloadPDF} 
      className="btn btn-success pl-5 mb-3" 
      style={{ padding: '10px 20px', borderRadius: '5px', cursor: 'pointer', fontWeight: 'bold', color: '#fff', backgroundColor: '#28a745', border: 'none', transition: 'background-color 0.3s' }}
      onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#218838'}
      onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#28a745'}
    >
      Download PDF
    </div>
  </div>
</div>

      <div className="table-container">
        {leaveData.length > 0 ? (
          <table className="leave-table table-striped table-light table small">
            <thead>
              <tr>
                <th>Emp ID</th>
                <th>Name</th>
                <th>Number of CL's Availed</th>
                <th>Number of LLP's Availed</th>
                <th>Number of ML's Availed</th>
                <th>Number of WFH's Availed</th>
                <th>Number of LP's Availed</th>
                <th>Number of EP's Availed</th>
              </tr>
            </thead>
            <tbody>
              {leaveData.map((employee) => (
                <tr key={employee.emp_id} className="employee-section">
                  <td className="text-left p-3">{employee.emp_id}</td>
                  <td className="text-left p-3">{employee.user_name}</td>
                  <td className="text-center p-3" title={`${leaveCount(employee.leaveTypes, "CL-Casual Leave").leaveDates} (${leaveCount(employee.leaveTypes, "CL-Casual Leave").periods})`}>
                    {leaveCount(employee.leaveTypes, "CL-Casual Leave").totalDays}
                  </td>
                  <td className="text-center p-3" title={`${leaveCount(employee.leaveTypes, "Lop-Loss of Pay").leaveDates} (${leaveCount(employee.leaveTypes, "Lop-Loss of Pay").periods})`}>
                    {leaveCount(employee.leaveTypes, "Lop-Loss of Pay").totalDays}
                  </td>
                  <td className="text-center p-3" title={`${leaveCount(employee.leaveTypes, "ML-Medical Leave").leaveDates} (${leaveCount(employee.leaveTypes, "ML-Medical Leave").periods})`}>
                    {leaveCount(employee.leaveTypes, "ML-Medical Leave").totalDays}
                  </td>
                  <td className="text-center p-3" title={`${leaveCount(employee.leaveTypes, "WFH-Work From Home").leaveDates} (${leaveCount(employee.leaveTypes, "WFH-Work From Home").periods})`}>
                    {leaveCount(employee.leaveTypes, "WFH-Work From Home").totalDays}
                  </td>
                  <td className="text-center p-3" title={`${leaveCount(employee.leaveTypes, "LP-Late Permission").leaveDates} (${leaveCount(employee.leaveTypes, "LP-Late Permission").periods})`}>
                    {leaveCount(employee.leaveTypes, "LP-Late Permission").totalDays}
                  </td>
                  <td className="text-center p-3" title={`${leaveCount(employee.leaveTypes, "EP-Evening Permission").leaveDates} (${leaveCount(employee.leaveTypes, "EP-Evening Permission").periods})`}>
                    {leaveCount(employee.leaveTypes, "EP-Evening Permission").totalDays}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No leave applications found for the selected month and year.</p>
        )}
      </div>
    </div>
  );
};

export default GenerateReport;
