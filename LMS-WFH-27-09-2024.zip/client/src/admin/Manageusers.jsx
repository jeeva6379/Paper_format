import { useEffect, useState } from "react"; 

import axios  from "axios";
import { useNavigate } from "react-router-dom";

  import './Manageusers.css'

function Manageusers() {
  const API_URL = import.meta.env.VITE_API_URL;
const navigate = new useNavigate()
  
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState(null);
  const [editableUserId, setEditableUserId] = useState(null);
  const [editableUser, setEditableUser] = useState(null);

  useEffect(() => {
    const role = localStorage.getItem('role');
    if(role !== "Admin" && role !== "HR") navigate('/')
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/userdata`);
      setUsers(response.data);
      
      setLoading(false);
    } catch (error) {
      console.error("Error fetching users", error);
      setErrors("Error fetching users. Please try again later.");
      setLoading(false);
      if (error?.response?.status === 401) navigate("/")
    }
  };
  
  useEffect(() => {
    fetchUsers();
  }, []);

  const updateUser = async (updatedUser) => {
    try {
      const response = await axios.put(`${API_URL}/api/userdata-update/${updatedUser._id}`, {updatedUser});
      const updatedUsers = users.map(user => user._id === updatedUser._id ? response.data : user);
      setUsers(updatedUsers);
      setEditableUserId(null);
      setEditableUser(null);
      fetchUsers()
    } catch (error) {
      console.error("Error updating user", error);
      setErrors("Error updating user. Please try again later.");
      if (error?.response?.status === 401) navigate("/")
    }
  };

  const handleEditClick = (user) => {
    setEditableUserId(user._id);
    setEditableUser(user);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditableUser((prevUser) => ({ ...prevUser, [name]: value }));
  };

  const handleSaveClick = () => {
    updateUser(editableUser);
  };

  if (loading) return <p>Loading...</p>;
  if (errors) return <p>{errors}</p>;

  const handleCancelClick = () => {
    setEditableUserId(null);
  };
  
  const deleteUser = async (userId) => {
    
    if (!userId) {
      console.error("Invalid userId:", userId);
      return;
    }
  
    try {
      const response = await axios.delete(`${API_URL}/api/userdata-delete/${userId}`);
      if (response.status === 200) {
        const remainingUsers = users.filter(user => user._id !== userId);
        setUsers(remainingUsers);
      } else {
        setErrors("Error deleting user. Please try again later.");
      }
    } catch (error) {
      console.error("Error deleting user", error);
      setErrors("Error deleting user. Please try again later.");
      if (error?.response?.status === 401) navigate("/")
    }
  };

          
  return (
    <>

          <h3>All users</h3>
          {Array.isArray(users) && users.length > 0 ? (

<div className="table-container">
  
<table className="user-table " style={{textAlign:"left"}}>
  <thead>
    <tr className="bg-dark text-dark">
      <th>Emp_ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Role</th>
      <th>Password</th>
      <th>Designation</th>
      <th>Date of Joining</th>
      <th>Created At</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    {users.map((user) => (
      <tr key={user._id}>
        <td>{user.emp_id}</td>
        <td>
          {editableUserId === user._id ? (
            <input
              type="text"
              name="name"
              value={editableUser.name}
              onChange={handleChange}
            />
          ) : (
            user.name
          )}
        </td>
        <td>
          {editableUserId === user._id ? (
            <input
              type="email"
              name="email"
              value={editableUser.email}
              onChange={handleChange}
            />
          ) : (
            user.email
          )}
        </td>
        <td>
          {editableUserId === user._id ? (
            <input
              type="text"
              name="role"
              value={editableUser.role}
              onChange={handleChange}
            />
          ) : (
            user.role
          )}
        </td>
        <td>
          {editableUserId === user._id ? (
            <input
              type="text"
              name="password"
              value={editableUser.password}
              onChange={handleChange}
            />
          ) : (
            user.password
          )}
        </td>
        <td>
          {editableUserId === user._id ? (
            <input
              type="text"
              name="designation"
              value={editableUser.designation}
              onChange={handleChange}
            />
          ) : (
            user.designation
          )}
        </td>
        <td>{user.date_of_joining}</td>
        <td>{user.createdAt}</td>
        <td className="user-actions">
  {editableUserId === user._id ? (
    <div className="d-flex">
      <button style={{minWidth:'70px'}} onClick={ handleSaveClick} className="btn  btn-sm rounded-pill btn-dark">Save</button>
      <button style={{minWidth:'70px'}} onClick={handleCancelClick} className="btn  btn-sm rounded-pill btn-outline-dark">Cancel</button>
    </div>
  ) : (
    editableUserId === null && (
      <>
        <button style={{minWidth:'70px'}} onClick={() => handleEditClick(user)} className="btn btn-sm rounded-pill btn-dark">Edit</button>
        <button style={{minWidth:'70px'}} onClick={() => deleteUser(user._id)} className="btn btn-sm rounded-pill btn-outline-dark">Delete</button>
      </>
    )
  )}
</td>

      </tr>
    ))}
  </tbody>
</table>
</div>


) : (
  <div>No user data available</div>
)}

   
 </>
  
  );
}

export default Manageusers;
