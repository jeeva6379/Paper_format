const Input = ({type, id, placeholder, value, jeeva = 'yellow'}) => {


  return (
    <input type={type} id={id} placeholder={placeholder}  value={value}  style={{backgroundColor: jeeva}}/>
  )
}

export default Input



