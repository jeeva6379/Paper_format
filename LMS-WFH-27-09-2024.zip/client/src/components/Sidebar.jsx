import { useEffect, useState } from "react";

import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";

const Sidebar = () => {
  const navigate = useNavigate();
  const [name ,setname] = useState("name");
  const [role ,setrole] = useState("role");
  const [designation ,setdesignation] = useState("designation");
  const [emp_id ,setemp_id] = useState("emp_id");
  const [date_of_joining ,setdate_of_joining] = useState("doj");
  const [profile_pic_url ,setprofile_pic_url] = useState("profile-pic-url',");
  const API_URL = import.meta.env.VITE_API_URL; 
  const [showMobileMenuBool, setShowMobileMenuBool] = useState(false)

const getCurrentUserData = async()=> {
  try {
    const res = await axios.get(`${API_URL}/api/current-user`)
    if(res.status === 200) {
      const user = res.data.user
      
      localStorage.setItem('name', user.name);
      localStorage.setItem('company', user.company);
      localStorage.setItem('user_id', user._id);
      localStorage.setItem('role', user.role);
      localStorage.setItem('designation', user.designation);
      localStorage.setItem('emp_id', user.emp_id);
      localStorage.setItem('doj', user.date_of_joining);
      localStorage.setItem('profile-pic-url', res.data.profile_pic_url);

      setname( user.name);
      setrole( user.role);
      setdesignation( user.designation);
      setemp_id( user.emp_id);
      setdate_of_joining( user.date_of_joining);
      setprofile_pic_url(res.data.profile_pic_url);
      
   
      
    }
  } catch (error) {
    console.log('Error setting user data');
    navigate('/');

  }
}

useEffect(() => {
  getCurrentUserData()
}, []);

  
  
  const HandleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  const toggleMobileMenu = () => {
    setShowMobileMenuBool(val => !val)
  }

  return (
    (<div className="sidebar text-center">
      <div className="text-end">
        <button className="navbar-toggler" onClick={toggleMobileMenu}>Menu</button>
        </div>

      <div className={`nav-menu my-auto ${showMobileMenuBool && 'show'}`}>
      <div className="rounded-circle mx-auto mb-3" style={{ width: "200px", height: "200px", overflow:'hidden'}}>
      <img  src={profile_pic_url} alt="" style={{ width: "100%", height: "100%", objectFit: 'cover', objectPosition: 'top' }} />
      </div>
      <div className="">
       
        <div
          className="text-center text-nowrap"
          style={{ fontSize: "1.3rem", fontWeight: 500 }}
        >
          {name}
        </div>
        <div
          className="text-center"
          style={{ fontSize: "1rem", opacity: 0.65, letterSpacing: "1px" }}
        >
          {designation}
        </div>
        <hr />
        <div className="small mx-auto text-start d-table" style={{ opacity: 0.6 }}>
          <table>
            <tbody>
              <tr>
                <td className="pe-3 py-1">Employee ID</td>
                <td className="text-start"> : {emp_id}</td>
              </tr>
              <tr>
                <td className="pe-3 py-1">Date of Joining</td>
                <td className="text-start"> : {date_of_joining}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5">
              <Link
                className="btn btn-dark d-block"
                to="dashboard" onClick={toggleMobileMenu}
              >
                Dashboard
              </Link>
            </div>
        {role !== "Employee" && (
          <>
            <hr className="my-5" />
            <div className="mt-3">
              <Link
                className="btn btn-dark d-block"
                to="apply-leave" onClick={toggleMobileMenu}
              >
                Apply Leave
              </Link>
            </div>
          
            <div className="mt-3">
              <Link
                className="btn btn-dark d-block"
                to="create-user" onClick={toggleMobileMenu}
              >
                Create User
              </Link>
            </div>
            <div className="mt-3">
              <Link
                className="btn btn-dark d-block"
                to="manage-user" onClick={toggleMobileMenu}
              >
                Manage Users
              </Link>
            </div>
            <div className="mt-3">
              <Link
                className="btn btn-dark d-block"
                to="leave-applications" onClick={toggleMobileMenu}
              >
                Leave Applications
              </Link>
            </div>
            <div className="mt-3">
              <Link
                className="btn btn-dark d-block"
                to="generate-report" onClick={toggleMobileMenu}
              >
                Generate Report
              </Link>
            </div>
          </>
        )}
      </div>
      </div>
      <div className="w-100 ">
          <a
            className="btn btn-outline-dark d-block"
            href="#"
            onClick={HandleLogout}
            style={{display: 'block', width: '100%'}}
          >
            Logout
          </a>
        </div>
    </div>)
  );
};

export default Sidebar;
