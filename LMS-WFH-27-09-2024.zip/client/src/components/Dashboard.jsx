
const Dashboard = () => {


    const name = localStorage.getItem('name');

  return (
    <div>
      <h3>Welcome {name} !!</h3>
    </div>
  )
}

export default Dashboard
