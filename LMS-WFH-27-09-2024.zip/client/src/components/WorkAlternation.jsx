import { useEffect, useState } from 'react'

import IndividualAlternations from './IndividualAlternations';

import './WorkAlternation.css'

const WorkAlternation = ({dayIndex, data, setWorkAlternationData, alternationEmployees}) => {
    const [individualAlternations, setIndividualAlternations] = useState([]);
    
     const updateWorkAlternationData = (workIndex, field, value) => {
      setWorkAlternationData(prevState => {
        const newWorkAlternations = [...prevState];
        newWorkAlternations[dayIndex] = newWorkAlternations[dayIndex].map((work, index) =>
          index === workIndex ? { ...work, [field]: value } : work
        );
        return newWorkAlternations;
      });
    };
  
    const handleAddWork = () => {
      setWorkAlternationData(prevState => {
        const newWorkAlternations = [...prevState];
        newWorkAlternations[dayIndex] = [...newWorkAlternations[dayIndex], { work: '', employee_id: '' }];
        return newWorkAlternations;
      });
    };
    const handleRemoveWork = (workIndex) => {
      setWorkAlternationData(prevState => {
        const newWorkAlternations = [...prevState];
        newWorkAlternations[dayIndex] = newWorkAlternations[dayIndex].filter((_, index) => index !== workIndex);
        return newWorkAlternations;
      });
    };

    useEffect(() => {
        let rows = []
        data.map((item, index) =>  {          
            rows.push(<IndividualAlternations key={index} workIndex={index} alternationEmployees={alternationEmployees} removeRow={()=>{handleRemoveWork(index)}} data={item} 
            updateWorkData={(field, value)=>{updateWorkAlternationData(index, field, value)}}/>);
          })

        setIndividualAlternations(rows)
    }, [alternationEmployees, data]);

  return (
    <tr key={dayIndex}>
        <td className='align-middle text-nowrap'>Day - {dayIndex + 1}</td>
        <td colSpan={2}>    
            <table className='table_1'>
                <tbody>
                    {individualAlternations}
                </tbody>
            </table>
        </td>
        <td className='align-bottom'>
            <div className='d-flex justify-content-center align-items-center gap-2'>
                <button style={{fontSize: '1rem'}} className='btn btn-dark' onClick={handleAddWork}>+</button>
            </div>
        </td>
    </tr>)
}

export default WorkAlternation

