import { useEffect, useRef } from "react";

const IndividualAlternations = ({data, workIndex, alternationEmployees, removeRow, updateWorkData}) => {
  const inputRef = useRef("")
  const selectRef = useRef("")
    useEffect(() => {
    inputRef.current.value = data.work || ""
    selectRef.current.value = data.employee_id || ""
    }, [data]);

  return (
    <tr key={workIndex}>
      <td className="px-4">
        <input ref={inputRef} style={{width: '250px'}} className="form-control line-input py-2" type="text"  placeholder={`work - ${workIndex + 1}`} onChange={e => updateWorkData( 'work', e.target.value)} />
        </td>
      <td className="px-4">
        <select ref={selectRef} style={{width: '250px'}} className="line-input py-2" defaultValue="" onChange={e => updateWorkData( 'employee_id', e.target.value)}>
          <option value=""  disabled>work alternation  to</option>
          {
            alternationEmployees.map(employee => (<option key={employee._id} value={employee._id}>{employee.name}</option>))
          } 
        </select>
        </td>
        <td><button style={{fontSize: '1rem', border: '1px solid #ccc'}} className='btn btn-light' onClick={removeRow}>-</button></td>
    </tr>
  )
}

export default IndividualAlternations
