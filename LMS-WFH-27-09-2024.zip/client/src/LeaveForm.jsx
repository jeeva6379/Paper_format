import { useEffect, useState } from "react";

import axios from "axios";
import WorkAlternation from "./components/WorkAlternation";

import "./LeaveForm.css";

function LeaveForm() {
  const API_URL = import.meta.env.VITE_API_URL;

  const [selectedOption, setSelectedOption] = useState("");
  const [numberOfDays, setNumberOfDays] = useState(1);
  const [formattedDateTime, setFormattedDateTime] = useState("");
  const [fileUpload, setFileUpload] = useState("");
  const [workAlternationData, setWorkAlternationData] = useState(Array.from({ length: 1 }, () => ([{ work: '', employee_id: '' }])));
  const [error, setError] = useState({});

  
  const [workAlternationTableRows, setWorkAlternationTableRows] = useState([]);
  const [leaveDetails, setLeaveDetails] = useState({
    leaveSession: "", 
    formDate: "",
    toDate: "",
    permission: "",
  });


  const [reason, setReason] = useState("");


const clTaken = localStorage.getItem("casual_leave_data") == 'true';







  
  const handleChange = (e) => {
    setSelectedOption(e.target.value);
    // setLeaveDetails.formDate(e.target.value);
    setError({}); 
    
    // Clear error when the user selects an option

  };

  const numberOfDaysChanged = (e) => {
    const value = e.target.value;
    const clampedValue = Math.min(30, Math.max(1, value));
    setNumberOfDays(clampedValue);
    const data = Array.from({ length: clampedValue }, () => ([{ work: '', employee_id: '' }]));
    setWorkAlternationData(data);
  };

  


  const handleLeaveDetailsChange = (e) => {
    const { name, value } = e.target;
    setLeaveDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    }));
    if (name === "permission" && value) {
      const formattedDateTime = formatDateTime(new Date(value));
      setFormattedDateTime(formattedDateTime);
    }
  };


  const handleDateChange = (e) => {
    const value = e.target.value.replace(/[^0-9]/g, ''); 
console.log('value', value);
    let formattedDate = '';

    // Format the input to dd-mm-yyyy
    if (value.length > 0) {
        formattedDate += value.substring(0, 2); // Add day
    }
    if (value.length > 2) {
        formattedDate += '-' + value.substring(2, 4); // Add month
    }
    if (value.length > 4) {
        formattedDate += '-' + value.substring(4, 8); // Add year
    }

    e.target.value = formattedDate;
    handleLeaveDetailsChange(e)

};

  

  const getAlternateEmployeesList = async ()=> {
    const user_id = localStorage.getItem('user_id');
    try {
      const response = await axios.get(`${API_URL}/api/alternation-users-list/${user_id}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching users', error);
    }
  }

  const workAlternationFn = async ()=>{
    const alternationEmployees = await getAlternateEmployeesList()
    let rows = [];
      
    for (let i = 0; i < numberOfDays; i++) {
      rows.push(
        <WorkAlternation
          key={i}
          dayIndex={i}
          data={workAlternationData[i]}
          setWorkAlternationData={setWorkAlternationData}
          alternationEmployees={alternationEmployees}
        />
      );
    }
    setWorkAlternationTableRows(rows);
  }

  useEffect( () => {
    workAlternationFn()
  }, [numberOfDays, workAlternationData]);

  const Company = localStorage.getItem("company");

  const displayName =
    Company === "EJESRA" ? (
      <div className="d-md-flex justify-content-center align-items-center gap-4">
        <img
          src="https://ejesra.com/images/eJESRA-icon.png"
          alt="EJESRA Logo"
          style={{ width: "70px", height: "70px" }}
        />
        <div>eJESRA</div>
      </div>
    ) : Company === "IRO" ? (
      <div className="d-md-flex justify-content-center align-items-center gap-4">
        <img
          src="https://iroglobal.com/IRO.png"
          alt="IRO Logo"
          style={{ width: "70px", height: "70px" }}
        />
        <div>Inventive Research Organization</div>
      </div>
    ) : Company === "CONFYY" ? (
      <div className="d-md-flex justify-content-center align-items-center gap-4">
        <img
          src="https://confyy.com/confyy%20logo.png"
          alt="CONFYY Logo"
          style={{
            width: "70px",
            height: "70px",
            borderRadius: "50%",
            backgroundColor: "#fff",
            padding: "4px",
          }}
        />
        <div>Confyy</div>
      </div>
    ) : (
      Company || "Company name not available"
    );

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFileUpload(selectedFile);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedOption) {
      setError(data => ({...data, leaveType: 'Please select a type of leave.'}));
      console.log('Please select a type of leave.')      
      return;
    }
    if(!leaveDetails.formDate && !(selectedOption === 'ep-evening permission' || selectedOption === 'lp-late permission')){
      
      setError(data => ({...data, fromDate: 'From date required.'}));
      console.log('From date required.')      
      return;
    } 
    if(!reason){
      setError(data => ({...data, reason: 'Reason is required.'}));
      console.log('Reason is required.')      
      return;
    } 



    console.log('Form submitted with leave type:', selectedOption);

    const formData = new FormData();
    formData.append("leavetype", selectedOption);
    formData.append("numberOfDays", numberOfDays);
    formData.append("leaveSession", leaveDetails.leaveSession);
    formData.append("fromDate", leaveDetails.formDate);
    formData.append("toDate", leaveDetails.toDate);
    formData.append("permission", formattedDateTime);
    formData.append("reason", reason);
    formData.append("file", fileUpload);

    const workAlternationData_ = workAlternationData.map((dayWork, index) =>({
      dayNumber: index + 1,
      workAlternations: dayWork
    }))
      
    const workAlternationDataString = JSON.stringify(workAlternationData_)

    formData.append("workAlternationData", workAlternationDataString);
    for (let [key, value] of formData.entries()) {
      console.log(`${key}: ${value}`);
    }

    try {
      const response = await axios.post(
        `${API_URL}/api/leave-applications`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      console.log(response.data);
      alert("Leave applied successfully.");
     window.location.reload();
    } catch (error) {
      console.error("Error submitting form data", error);
    }
  };

  const formatDateTime = (date) => {
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();

    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12;
    hours = hours ? hours : 12;
    const formattedTime = `${String(hours).padStart(
      2,
      "0"
    )}:${minutes}:${ampm}`;

    return `${day}-${month}-${year} | ${formattedTime}`;
  };


  

  return (
    <>
          <div className="leave-form-content py-5">
            <h3 className="text-center ">{displayName}</h3>
            <hr />

            <div className="Leave_Section mt-5">
              {/* Type of Leave */}
              <div className="row mb-5 justify-content-center">
                <div className="col-lg-8">
                  <div className="mb-2">
                    <strong className="text-danger">Type of Leave</strong>
                  </div>
                  <select
                    id="leaveType"
                    className="form-select custom-select-no-border form-control line-input py-2 "
                    onChange={handleChange}
                    value={selectedOption}
                  >
                    <option value="" disabled>
                      Select Mode of Leave
                    </option>
                    {!clTaken && <option value="CL-Casual Leave">CL-Casual Leave</option>}
                    <option value="ML-Medical Leave">ML-Medical Leave</option>
                    <option value="WFH-Work From Home">WFH-Work from Home</option>
                    <option value="EP-Evening Permission">EP-Evening Permission</option>
                    <option value="LP-Late Permission">LP-Late Permission</option>
                    <option value="Lop-Loss of Pay">LOP-Loss of Pay</option>
                  </select>


      


                  {error && error.leaveType && <div className="text-danger mt-2 text-center">{error.leaveType}</div>}

                </div>
              </div>

              {/* Duration of Leave */}
              {/* <div className="row justify-content-center mb-4">
                <div className="col-lg-8">
                  <div className="mb-2">
                    <strong className="text-danger">Duration of Leave</strong>
                  </div>

                  {selectedOption === "LP-Late Permission" ||
                  selectedOption === "EP-Evening Permission" ? (
                    <div className="row  mb-3">
                      <div className="col-lg-6 my-auto">
                        Permission:
                        <input
                          className="form-check-input ms-4"
                          type="radio"
                          name="leaveSession"
                          id="fromNowRadioFN"
                          value="FN"
                          onChange={handleLeaveDetailsChange}
                        />
                        <label
                          className="form-check-label ps-2"
                          htmlFor="fromNowRadioFN"
                        >
                          FN
                        </label>
                        <input
                          className="form-check-input ms-4"
                          type="radio"
                          name="leaveSession"
                          id="fromNowRadioAN"
                          value="AN"
                          onChange={handleLeaveDetailsChange}
                        />
                        <label
                          className="form-check-label ps-2"
                          htmlFor="fromNowRadioAN"
                        >
                          {" "}
                          AN{" "}
                        </label>
                      </div>
                      <div className="col-lg-6 ">
                        <input
                          type="text"
                          name="formDate"
                          className="form-control line-input py-2 text-center"
                          placeholder="DD-MM-YYYY"
                          onChange={handleLeaveDetailsChange}
                        />
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="row  mb-3">
                        <div className="col-lg-6 my-auto">
                          From:
                          <input
                            className="form-check-input ms-4"
                            type="radio"
                            name="leaveSession"
                            id="fromNowRadioFN"
                            value="FN"
                            onChange={handleLeaveDetailsChange}
                          />
                          <label
                            className="form-check-label ps-2"
                            htmlFor="fromNowRadioFN"
                          >
                            FN
                          </label>
                          <input
                            className="form-check-input ms-4"
                            type="radio"
                            name="leaveSession"
                            id="fromNowRadioAN"
                            value="AN"
                            onChange={handleLeaveDetailsChange}
                          />
                          <label
                            className="form-check-label ps-2"
                            htmlFor="fromNowRadioAN"
                          >
                            {" "}
                            AN{" "}
                          </label>
                        </div>
                        <div className="col-lg-6 ">
                          <input
                            type="text"
                            name="formDate"
                            className="form-control line-input py-2 text-center"
                            placeholder="DD-MM-YYYY"
                            onChange={handleLeaveDetailsChange}
                               maxLength="10"
  
                          />
                          {error && error.fromDate && <div className="text-danger mt-2 text-center">{error.fromDate}</div>}
                        </div>
                      </div>

                      <div className="row  mb-3">
                        <div className="col-lg-6 my-auto">To:</div>
                        <div className="col-lg-6 ">
                          <input
                            type="text"
                            name="toDate"
                            className="form-control line-input py-2 text-center"
                            placeholder="DD-MM-YYYY"
                            onChange={handleLeaveDetailsChange}
                            maxLength="10"
                           
                          />
                        </div>
                      </div>
                      <div className="row ">
                        <div className="col-lg-6 my-auto">No. of days</div>
                        <div className="col-lg-6 ">
                          <input
                            type="number"
                            className="form-control line-input py-2 text-center"
                            onChange={numberOfDaysChanged}
                            placeholder="days"
                          />
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
 */}

              <div className="row justify-content-center mb-4">
  <div className="col-lg-8">
    <div className="mb-2">
      <strong className="text-danger">Duration of Leave</strong>
    </div>

    {selectedOption === "LP-Late Permission" ||
    selectedOption === "EP-Evening Permission" ? (
      <div className="row  mb-3">
        <div className="col-lg-6 my-auto">
          Permission:
          <input
            className="form-check-input ms-4"
            type="radio"
            name="leaveSession"
            id="fromNowRadioFN"
            value="FN"
            onChange={handleLeaveDetailsChange}
          />
          <label
            className="form-check-label ps-2"
            htmlFor="fromNowRadioFN"
          >
            FN
          </label>
          <input
            className="form-check-input ms-4"
            type="radio"
            name="leaveSession"
            id="fromNowRadioAN"
            value="AN"
            onChange={handleLeaveDetailsChange}
          />
          <label
            className="form-check-label ps-2"
            htmlFor="fromNowRadioAN"
          >
            AN
          </label>
        </div>
        <div className="col-lg-6 ">
          <input
            type="text"
            name="formDate"
            className="form-control line-input py-2 text-center"
            placeholder="DD-MM-YYYY"
            onChange={handleDateChange}
            maxLength="10"
          />
        </div>
      </div>
    ) : selectedOption === "Lop-Loss of Pay" ? (
      <>
        <div className="row  mb-3">
          <div className="col-lg-6 my-auto">From:</div>
          <div className="col-lg-6 ">
            <input
              type="text"
              name="formDate"
              className="form-control line-input py-2 text-center"
              placeholder="DD-MM-YYYY"
              onChange={handleDateChange}
              maxLength={10}
            />
            {error && error.fromDate && <div className="text-danger mt-2 text-center">{error.fromDate}</div>}
          </div>
        </div>

        <div className="row  mb-3">
          <div className="col-lg-6 my-auto">To:</div>
          <div className="col-lg-6 ">
            <input
              type="text"
              name="toDate"
              className="form-control line-input py-2 text-center"
              placeholder="DD-MM-YYYY"
              onChange={handleDateChange}
              maxLength={10}
            />
          </div>
        </div>
        <div className="row ">
          <div className="col-lg-6 my-auto">No. of days</div>
          <div className="col-lg-6 ">
            <input
              type="number"
              className="form-control line-input py-2 text-center"
              onChange={numberOfDaysChanged}
              placeholder="days"
            />
          </div>
        </div>
      </>
    ) : (
      <>
        <div className="row  mb-3">
          <div className="col-lg-6 my-auto">
            From:
            <input
              className="form-check-input ms-4"
              type="radio"
              name="leaveSession"
              id="fromNowRadioFN"
              value="FN"
              onChange={handleDateChange}
            />
            <label
              className="form-check-label ps-2"
              htmlFor="fromNowRadioFN"
            >
              FN
            </label>
            <input
              className="form-check-input ms-4"
              type="radio"
              name="leaveSession"
              id="fromNowRadioAN"
              value="AN"
              onChange={handleLeaveDetailsChange}
            />
            <label
              className="form-check-label ps-2"
              htmlFor="fromNowRadioAN"
            >
              AN
            </label>
          </div>
          <div className="col-lg-6 ">
            <input
              type="text"
              name="formDate"
              className="form-control line-input py-2 text-center"
              placeholder="DD-MM-YYYY"
              onChange={handleDateChange}
              maxLength="10"
            />
            {error && error.fromDate && <div className="text-danger mt-2 text-center">{error.fromDate}</div>}
          </div>
        </div>

        <div className="row  mb-3">
          <div className="col-lg-6 my-auto">To:</div>
          <div className="col-lg-6 ">
            <input
              type="text"
              name="toDate"
              className="form-control line-input py-2 text-center"
              placeholder="DD-MM-YYYY"
              onChange={handleDateChange}
              maxLength="10"
            />
          </div>
        </div>
        <div className="row ">
          <div className="col-lg-6 my-auto">No. of days</div>
          <div className="col-lg-6 ">
            <input
              type="number"
              className="form-control line-input py-2 text-center"
              onChange={numberOfDaysChanged}
              placeholder="days"
            />
          </div>
        </div>
      </>
    )}
  </div>
</div>





              <div className="row mb-5 mt-4 justify-content-center">
                <div className="col-lg-8">
                  <div className="mb-2">
                    <strong className="text-danger">Reason of leave</strong>
                  </div>
                  <input
                    type="text"
                    className="form-control line-input py-2"
                    placeholder="Reason for the leave..."
                    onChange={(e) => setReason(e.target.value)}
                  />
                  {error && error.reason && <div className="text-danger mt-2 text-center">{error.reason}</div>}
                </div>
              </div>
            </div>

            {selectedOption === "ML-Medical Leave" && (
              <div className="row mb-5 mt-4 justify-content-center">
                <div className="col-lg-8">
                  <div className="mb-2">
                    <strong className="text-danger">
                      Upload Medical Certificate:
                    </strong>
                  </div>
                  <input
                    type="file"
                    id="fileUpload"
                    name="fileUpload"
                    onChange={handleFileChange}
                    className="form-control mt-2"
                  />
                </div>
              </div>
            )}

            {/* Work Alternation */}
            <div className="work-alternation mt-5">
              <div className="text-center mb-2">
                <strong className="text-danger">Work Alternation</strong>
              </div>
              <div className="table-responsive">
                <table className="work-alternation-table table table-bordered table-light ">
                  <thead>
                    <tr className="text-center">
                      <th>Days</th>
                      <th>Work responsibility</th>
                      <th>Assigned to</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>{workAlternationTableRows}</tbody>
                </table>
              </div>
            </div>

            <div className="row justify-content-center mt-3">
              <div className="col-lg-3">
                <a
                  className="btn btn-dark d-block"
                  href="#"
                  onClick={handleSubmit}
                >
                  Submit
                </a>
              </div>
            </div>
          </div>
    </>
  );
}

export default LeaveForm;
