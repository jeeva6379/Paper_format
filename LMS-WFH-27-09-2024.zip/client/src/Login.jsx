import { useState } from "react";

import { Form  } from "react-bootstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login() {
    const API_URL = import.meta.env.VITE_API_URL;
    const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setErrors("Invalid credentials");

    const validationErrors = {};

    // Validate email
    if (!email) {
      validationErrors.email = "Email is required";
      console.log("Email is required");
    }

    // Validate password
    if (!password) {
      validationErrors.password = "Password is required";
    } else if (password.length < 8) {
      validationErrors.password = "Password must be at least 8 characters long";
    } else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/.test(password)) {
      validationErrors.password =
        "Password must contain at least one lowercase letter, one uppercase letter, one number, and one special character";
    }

    try {

      const response = await axios.post(`${API_URL}/api/login`,{email , password});
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
        alert('Logged in Successfully')
        setEmail('');
        setPassword('');

    const res = await axios.get(`${API_URL}/api/current-user`, { headers: { 'Authorization': `Bearer ${response.data.token}` } } )
      const user = res.data.user
      // console.log('user',user);
      
      localStorage.setItem('name', user.name);
      localStorage.setItem('company', user.company);
      localStorage.setItem('user_id', user._id);
      localStorage.setItem('role', user.role);
      localStorage.setItem('designation', user.designation);
      localStorage.setItem('emp_id', user.emp_id);
      localStorage.setItem('doj', user.date_of_joining);
      localStorage.setItem('profile-pic-url', res.data.profile_pic_url);
      localStorage.setItem("casual_leave_data", res.data.clTaken)

      // console.log("casual_leave_data", res.data.clTaken)

        navigate('/apply-leave')
    }
    } catch (error) {
      setErrors('Invalid email or password')
      alert('Invalid email or password')
      

    }

  };

  return (
    <>
      <div className="Page">
        <div className="main">
          <div className="signup">
            <div className="text-center">
              <h2>
                {/* <strong>IRO</strong> */}
              </h2>
              <h4 className="opacity-75">Leave Management System</h4>
            </div>
            <Form onSubmit={handleSubmit}>
              <div className="container mt-5">
                <div className="form-floating mb-4">
                  {/* <input id="emailInput" className=" form-control line-input " type="text" placeholder="Email address" value={email} onChange={handleEmailChange} isInvalid={!!errors.email}/> */}
                  <input
                    id="emailInput"
                    className=" form-control line-input "
                    type="text"
                    placeholder="Email address"
                    value={email}
                    onChange={handleEmailChange}
                  />
                  <label htmlFor="emailInput">Email address</label>
                </div>

                <Form.Control.Feedback type="invalid">
                  {errors.email}
                </Form.Control.Feedback>

                <div className="form-floating mb-4">
                  {/* <input type="password" className="form-control line-input " id="passwordInput" placeholder="Password"  value={password} onChange={handlePasswordChange} isInvalid={!!errors.password} /> */}
                  <input
                    type="password"
                    className="form-control line-input "
                    id="passwordInput"
                    placeholder="Password"
                    value={password}
                    onChange={handlePasswordChange}
                  />
                  <label htmlFor="passwordInput">Password</label>
                </div>

                <Form.Control.Feedback type="invalid">
                  {errors.password}
                </Form.Control.Feedback>

                <button
                  className="home-btn mt-5"
                  type="submit"
                  onClick={handleSubmit}
                >
                  Log-in
                </button>
              </div>
            </Form>

 
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
