
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, AlignmentType, ImageRun, Header,Table, TableRow, TableCell, BorderStyle, WidthType } = require('docx');

const app = express();
const port = 3001;

// Middleware setup
app.use(bodyParser.json());
app.use(cors());

// Ensure the uploads directory exists
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});
const upload = multer({ storage });

// Helper functions
const cmToTwips = (cm) => Math.round(cm * 567);
const lineHeight = 1.5 * 240;
const referenceLineHeight = 1.5 * 240;
const firstLineIndent = cmToTwips(1.27);

// Margin definitions
const topMargin = cmToTwips(2.65);
const rightMargin = cmToTwips(2.54);
const bottomMargin = cmToTwips(1.68);
const leftMargin = cmToTwips(2.54);

// Function to split text into paragraphs with specific formatting
const splitTextIntoParagraphs = (text, isReferenceSection = false, fontSize = 24) => {
  const lines = text.split('\n');
  return lines.map((line, index) => new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    indent: isReferenceSection ? {} : (index === 0 ? { firstLine: firstLineIndent } : {}),
    spacing: { line: isReferenceSection ? referenceLineHeight : lineHeight },
    children: [new TextRun({ text: line, size: fontSize, preserveWhitespace: true })],
  }));
};

// Function to split text into runs, handling superscripts
const splitTextIntoRuns = (text, isAffiliation = false) => {
  const runs = [];
  let currentRun = {
    text: '',
    size: isAffiliation ? 22 : 32,
    bold: !isAffiliation,
    superScript: false,
  };

  for (const char of text) {
    const isSuperScript = /\d/.test(char) || (isAffiliation && char === ',');

    if (isSuperScript && !currentRun.superScript) {
      if (currentRun.text) {
        runs.push(new TextRun(currentRun));
      }
      currentRun = {
        text: '',
        size: isAffiliation ? 22 : 32,
        bold: !isAffiliation,
        superScript: true,
      };
    } else if (!isSuperScript && currentRun.superScript) {
      if (currentRun.text) {
        runs.push(new TextRun(currentRun));
      }
      currentRun = {
        text: '',
        size: isAffiliation ? 22 : 32,
        bold: !isAffiliation,
        superScript: false,
      };
    }

    currentRun.text += char;
  }

  if (currentRun.text) {
    runs.push(new TextRun(currentRun));
  }

  return runs;
};

// Function to split affiliation text into paragraphs
const splitAffiliationIntoParagraphs = (text) => {
  const lines = text.split('\n');
  return lines.map(line => new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: lineHeight },
    indent: {}, // No indentation for affiliation section
    children: splitTextIntoRuns(line, true),
  }));
};

// Function to format emails into superscript runs


// Function to format emails into Paragraphs
const formatEmails = (emailString) => {
  // Split the input string by commas and trim any extra whitespace
  const emailArray = emailString.split(',').map(email => email.trim());

  // Create the label text run
  const labelRun = new TextRun({
    text: 'E-mail: ',
    bold: true,
    size: 18 
  });

  // Create an array to hold formatted runs
  const formattedEmails = emailArray.flatMap((email, index) => {
    // Separate the first character from the rest of the email address
    const firstChar = email.charAt(0);
    const restOfEmail = email.slice(1);

    // Create superscript text run for the first character
    const firstCharRun = new TextRun({
      text: firstChar,
      size: 18,
      superScript: true // Make this text superscript
    });

    // Create normal text run for the rest of the email address
    const restOfEmailRun = new TextRun({
      text: restOfEmail,
      size: 18
    });

    // Add the comma and space after each email except the last one
    const separator = (index < emailArray.length - 1) ? ', ' : '';

    // Create a text run for the separator
    const separatorRun = new TextRun({
      text: separator,
      size: 18
    });

    // Combine the superscript first character, the rest of the email, and the separator
    return [firstCharRun, restOfEmailRun, separatorRun];
  });

  // Return a single paragraph with the label and all email runs joined together
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    spacing: { line: lineHeight },
    children: [labelRun, ...formattedEmails]
  });
};


// Helper function to create header content
function createHeaderContent(title, image) {
  // Read image file
  let imageBuffer;
  try {
    imageBuffer = fs.readFileSync(path.join(__dirname, `./Journal_Images/${image}`));
  } catch (err) {
    console.error('Error reading image file:', err);
    // Handle error (e.g., fallback to a default image or throw an error)
    return new Header({
      children: [new Paragraph({ text: 'Error loading image', alignment: AlignmentType.END })],
    });
  }

  return new Header({
    children: [
      new Table({
        rows: [
          new TableRow({
            children: [
              new TableCell({
                children: [
                  new Paragraph({
                    alignment: AlignmentType.LEFT,
                    children: [
                      new TextRun({
                        text: title.titleLine1, // First line of the title
                        bold: true,
                        size: 14, // Adjust size (1/2 pt unit)
                      }),
                      new TextRun({
                        break: 1, // Add a line break
                      }),
                      new TextRun({
                        text: title.titleLine2, // Second line of the title
                        bold: true,
                        size: 14, // Adjust size (1/2 pt unit)
                      }),
                    ],
                  }),
                ],
                width: { size:92, type: WidthType.PERCENTAGE }, // Adjust width as needed
                borders: { // Remove borders from the cell
                  top: { style: BorderStyle.NONE },
                  bottom: { style: BorderStyle.NONE },
                  left: { style: BorderStyle.NONE },
                  right: { style: BorderStyle.NONE },
                },
              }),
              new TableCell({
                children: [
                  new Paragraph({
                    alignment: AlignmentType.END,
                    children: [
                      new ImageRun({
                        data: imageBuffer,
                        transformation: {
                          width: 55, // Adjust the width as needed
                          height: 40, // Adjust the height as needed
                        },
                      }),
                    ],
                  }),
                ],
                width: { size: 8, type: WidthType.PERCENTAGE }, // Adjust width as needed
                borders: { // Remove borders from the cell
                  top: { style: BorderStyle.NONE },
                  bottom: { style: BorderStyle.NONE },
                  left: { style: BorderStyle.NONE },
                  right: { style: BorderStyle.NONE },
                },
              }),
            ],
          }),
        ],
        borders: { // Remove borders from the table
          top: { style: BorderStyle.NONE },
          bottom: { style: BorderStyle.NONE },
          left: { style: BorderStyle.NONE },
          right: { style: BorderStyle.NONE },
          insideHorizontal: { style: BorderStyle.NONE },
          insideVertical: { style: BorderStyle.NONE },
        },
      }),
      new Paragraph({ text: '', spacing: { before: 400 } }) // Add spacing below the header
    ],
  });
}
// Example data
const titlesAndImages = [
  { Journal_title:"aicn", titleLine1: "Journal of Artificial Intelligence and Capsule Networks (ISSN: 2582-2012)", titleLine2: "www.irojournals.com/aicn/", image: "aicn.jpg" },
  { Journal_title:"jucct", titleLine1: "Journal of Ubiquitous Computing and Communication Technologies (ISSN: 2582-337X)", titleLine2: "www.irojournals.com/jucct/", image: "jucct.jpg" },
  { Journal_title:"iroeea", titleLine1: "Journal of Electrical Engineering and Automation (ISSN: 2582-3051)", titleLine2: "www.irojournals.com/iroeea/", image: "iroeea.jpg" },
  { Journal_title:"iroiip", titleLine1: "Journal of Innovative Image Processing (ISSN: 2582-4252)", titleLine2: "www.irojournals.com/iroiip/", image: "iroiip.jpg" },
  { Journal_title:"iroismac", titleLine1: "Journal of IoT in Social, Mobile, Analytics, and Cloud (ISSN: 2582-1369)", titleLine2: "www.irojournals.com/iroismac/", image: "iroismac.png" },
  { Journal_title:"itdw", titleLine1: "Journal of Information Technology and Digital World (ISSN: 2582-418X)", titleLine2: "www.irojournals.com/itdw/", image: "itdw.jpg" },
  { Journal_title:"iroei", titleLine1: "Journal of Electronics and Informatics (ISSN: 2582-3825)", titleLine2: "www.irojournals.com/iroei/", image: "iroei.jpg" },
  { Journal_title:"jscp", titleLine1: "Journal of Soft Computing Paradigm (ISSN: 2582-2640)", titleLine2: "www.irojournals.com/jscp/", image: "jscp.png" },
  { Journal_title:"rrrj", titleLine1: "Recent Research Reviews Journal (ISSN: 2583-7079)", titleLine2: "https://irojournals.com/rrrj", image: "rrrj.png" },
  { Journal_title:"irosws", titleLine1: "IRO Journal on Sustainable Wireless Systems (ISSN: 2582-3167)", titleLine2: "www.irojournals.com/irosws/", image: "irosws.jpg" },
  { Journal_title:"tcsst", titleLine1: "Journal of Trends in Computer Science and Smart Technology (ISSN: 2582-4104)", titleLine2: "www.irojournals.com/tcsst/", image: "tcsst.jpg" },
  // Add more titles and images as needed
];

// Inside the POST route handler
app.post('/submit', upload.array('images'), async (req, res) => {
  try {
    const { title, name, abstract, keywords, sections, references, affiliation, email,journalTitle } = JSON.parse(req.body.data);


    // Find the matched title and image
    const matchedItem = titlesAndImages.find(item => item.Journal_title === journalTitle);

    if (!matchedItem) {
      return res.status(400).send('Invalid journal title');
    }

    // Create header with matched title and image
    const header = createHeaderContent(matchedItem, matchedItem.image);


 // Load the image for the header
//  const headerImageBuffer = fs.readFileSync(path.join(__dirname, './Journal_Images/./aicn.jpg'));



//  const header = new Header({
//   children: [
//     new Table({
//       rows: [
//         new TableRow({
//           children: [
//             new TableCell({
//               children: [
//                 new Paragraph({
//                   alignment: AlignmentType.LEFT,
//                   children: [
//                     new TextRun({
//                       text: "Journal of Artificial Intelligence and Capsule Networks (ISSN: 2582-2012)",
//                       bold: true,
//                       size: 14,
//                     }),
//                     new TextRun({
//                       break: 1, // Add a line break
//                     }),
//                     new TextRun({
//                       text: "www.irojournals.com/aicn/",
//                       bold: true,
//                       size: 14,
//                     }),
//                   ],
//                 }),
//               ],
//               width: { size: 50, type: "pct" }, // 50% width
//               borders: { // Remove borders from the cell
//                 top: { style: BorderStyle.NONE },
//                 bottom: { style: BorderStyle.NONE },
//                 left: { style: BorderStyle.NONE },
//                 right: { style: BorderStyle.NONE },
//               },
//             }),
//             new TableCell({
//               children: [
//                 new Paragraph({
//                   alignment: AlignmentType.END,
//                   children: [
//                     new ImageRun({
//                       data: headerImageBuffer,
//                       transformation: {
//                         width: 55, // Adjust the width as needed
//                         height: 40, // Adjust the height as needed
//                       },
//                     }),
//                   ],
//                 }),
//               ],
//               width: { size: 50, type: "pct" }, // 50% width
//               borders: { // Remove borders from the cell
//                 top: { style: BorderStyle.NONE },
//                 bottom: { style: BorderStyle.NONE },
//                 left: { style: BorderStyle.NONE },
//                 right: { style: BorderStyle.NONE },
//               },
//             }),
//           ],
//         }),
//       ],
//       borders: { // Remove borders from the table
//         top: { style: BorderStyle.NONE },
//         bottom: { style: BorderStyle.NONE },
//         left: { style: BorderStyle.NONE },
//         right: { style: BorderStyle.NONE },
//         insideHorizontal: { style: BorderStyle.NONE },
//         insideVertical: { style: BorderStyle.NONE },
//       },
//     }),
//     new Paragraph({ text: '', spacing: { before: 400 } }) 
//   ],
// });



    const docSections = [
      // new Paragraph({
      //   alignment: AlignmentType.CENTER,
      //   spacing: { line: lineHeight },
      //   children: [new TextRun({ text: title, bold: true, size: 48 })],
      //   spacing: { after: 400 },
      // }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: {
          line: lineHeight, 
          
        },
        children: [
          new TextRun({
            text: title,
            bold: true,
            size: 48 // Font size 24 pt (docx uses half-points)
          })
        ]
      }),
      new Paragraph({ spacing: { line: lineHeight }, children: splitTextIntoRuns(name) }),
      ...splitAffiliationIntoParagraphs(affiliation),
      formatEmails(email),  // Ensure formatEmails() is used correctly
      new Paragraph({
        spacing: { line: lineHeight },
        children: [new TextRun({ text: 'Abstract', bold: true, size: 24 })],
        spacing: { after: 200 },
      }),
      ...splitTextIntoParagraphs(abstract),
      new Paragraph({
        spacing: { line: lineHeight },
        children: [
          new TextRun({ text: 'Keywords: ', bold: true, size: 24 }),
          new TextRun({ text: keywords, size: 24 }),
        ],
      }),
    ];

    for (let i = 0; i < sections.length; i++) {
      const section = sections[i];
      docSections.push(
        new Paragraph({
          spacing: { line: lineHeight },
          children: [new TextRun({ text: section.title, bold: true, size: 24 })],
          spacing: { before: 400, after: 200 },
        }),
        ...splitTextIntoParagraphs(section.content)
      );

      if (req.files[i] && req.files[i].originalname) {
        const imagePath = path.join(__dirname, 'uploads', req.files[i].originalname);
        try {
          const imageBuffer = fs.readFileSync(imagePath);
          docSections.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new ImageRun({
                  data: imageBuffer,
                  transformation: {
                    width: 250,
                    height: 250,
                  },
                }),
              ],
              spacing: { before: 200, after: 200 },
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { line: lineHeight },
              children: [
                new TextRun({ text: `Figure ${i + 1}. `, bold: true, size: 24 }),
                new TextRun({ text: section.figure, size: 24 }),
              ],
            })
          );
        } catch (error) {
          console.error('Error reading image file:', error);
        }
      }

      section.subheadings.forEach((subheading) => {
        docSections.push(
          new Paragraph({
            spacing: { line: lineHeight },
            children: [new TextRun({ text: subheading, bold: true, size: 24 })],
            spacing: { before: 400, after: 200 },
          }),
          ...splitTextIntoParagraphs(subheading)
        );
      });
    }

    docSections.push(
      new Paragraph({
        spacing: { line: lineHeight },
        children: [new TextRun({ text: 'References', bold: true, size: 24 })],
        spacing: { before: 400, after: 200 },
      }),
      ...splitTextIntoParagraphs(references, true)
    );

    const doc = new Document({
      sections: [{
        properties: { margin: { top: topMargin, right: rightMargin, bottom: bottomMargin, left: leftMargin } },
        header: {
          margin: 708, 
          bottom: 708, 
                },      
        headers: {
          default: header,
        },
        children: docSections,
      }],
    });

    const buffer = await Packer.toBuffer(doc);
    res.writeHead(200, {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'Content-Disposition': 'attachment; filename="document.docx"',
      'Content-Length': buffer.length,
    });
    res.end(buffer);
    console.log('Document generated and sent successfully.');
  } catch (error) {
    console.error('Error generating document:', error);
    res.status(500).send('Internal Server Error');
  }
});


app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
